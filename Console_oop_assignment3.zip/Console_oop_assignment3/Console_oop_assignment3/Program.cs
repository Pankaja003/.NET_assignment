﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            Order obj = new Order(1, "xyz", "abc", 4, 500);
            int Id = obj.GetOrderId();
            string name = obj.GetCustomerName();
            string ItemName = obj.GetItemName();
            int Quantity = obj.GetItemQuantity();
            int Price = obj.GetItemPrice();
            Console.WriteLine("ID IS:" + Id.ToString());
            Console.WriteLine("Customer Name IS:" + name);
            Console.WriteLine("ItemName IS:" +ItemName);
            Console.WriteLine(" Quantity Is:" + Quantity.ToString());
            Console.WriteLine("Price IS:" + Price.ToString());
            
            int amt = obj.GetOrderAmount();
            Console.WriteLine("Order amount is:" + amt);
            obj.UpdateItemQuantity(5);
            Quantity = obj.GetItemQuantity();
            Console.WriteLine(" Updated Quantity is:" + Quantity);
         
            amt = obj.GetOrderAmount();
            Console.WriteLine("Order amount is:" + amt);
            Console.ReadLine();



        }
    }
}
