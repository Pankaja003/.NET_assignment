﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hassignment6
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            int lrg = 0;
            int j=0;


            Console.WriteLine("Enter the elements of array:");
            for (int i = 0; i <arr.Length; i++)
            {
                Console.WriteLine("Element-{0}:", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("array elements are:");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
          

            for (int i = 0; i < arr.Length; i++)
            {
                if (lrg < arr[i])
                {
                    lrg = arr[i];
                    j = i;
                }
            }
            int large2nd = 0;
           
            for (int i = 0; i < arr.Length; i++)
            {
                if (i == j)
                {
                    i++;
                    i--;
                }
                else
                {
                    if (large2nd < arr[i])
                    {
                        large2nd = arr[i];
                    }
                }
            }

            Console.WriteLine("Second largest element in the array is :" + large2nd);

            Console.ReadLine();
        }
     
    }
}
