﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_Assignment_properties
{
    class Order
    {
        private int OrderId;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;
        private static int count = 1000;
        public Order(string CustomerName,string ItemName,int ItemPrice,int ItemQuantity)
        {
            this.OrderId = ++Order.count;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;

        }

        public int POrderId
        {
            get
            {
                return this.OrderId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
           /* set
            {
                if (value.Length != 0)
                {
                    this.CustomerName = value;
                }
            }*/
        }
        public string PItemName
        {
            get
            {
                return this.ItemName;
            }
          /*  set
            {
                if(value.Length!=0)
                {
                    this.ItemName = value;
                }
            }*/
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public int PItemQuantity
        {
            get
            {
                return this.ItemQuantity;
            }
           set
            {
                if (value!= 0)
                {

                    this.ItemQuantity = value;
                }
            }
        }
        public int GetOrderAmount()
        {
            int amt = ItemQuantity * ItemPrice;
            return amt;
        }
    }
}
