﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_Assignment_properties
{
    class Program
    {
        static void Main(string[] args)
        {
            Order obj = new Order("abc", "xyz", 500, 4);
            Console.WriteLine(obj.POrderId);
            Console.WriteLine(obj.PCustomerName);
            Console.WriteLine(obj.PItemName);
            Console.WriteLine(obj.PItemPrice);
            Console.WriteLine(obj.PItemQuantity);
            int amt = obj.GetOrderAmount();
            Console.WriteLine("Amount is :" + amt);
          //  obj.PCustomerName = "abcd";
           // obj.PItemName = "opq";
            obj.PItemQuantity = 5;
            //Console.WriteLine(obj.PCustomerName);
            //Console.WriteLine(obj.PItemName);
            Console.WriteLine(obj.PItemQuantity);
            amt = obj.GetOrderAmount();
            Console.WriteLine("Amount is :" + amt);
            Console.ReadLine();




        }
    }
}
