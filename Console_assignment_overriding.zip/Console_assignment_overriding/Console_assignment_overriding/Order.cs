﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_assignment_overriding
{
    class Order
    {
        private int OrderId;
        private string CustomerName;
        protected int ItemQty;
        protected int ItemPrice;
        private static int count = 1000;
        public Order(string CustomerName,int ItemQty,int ItemPrice)
        {
            this.OrderId = ++Order.count;
            this.CustomerName = CustomerName;
            this.ItemQty = ItemQty;
            this.ItemPrice = ItemPrice;
        }
        public int POrderId
        {
            get
            {
                return this.OrderId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public int PItemQty
        {
            get
            {
                return this.ItemQty;
            }
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public virtual double GetOrderValue()
        { 
         
            double amt = ItemPrice * ItemQty;

            return amt;
        }
    }
}
