﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_assignment_overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Item qty:");
            int qty = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Item Price:");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the type of Order:");
            string type = Console.ReadLine();
            Order obj = null;
            if(type=="Order")
            {
                obj = new Order(name, qty, price);
            }
            else if(type=="Order_Overseas")
            {
                obj = new Order_Overseas(name, qty, price);
            }
            if (obj != null)
            {
                Console.WriteLine("Order id is:" + obj.POrderId);
                Console.WriteLine("Customer name is :" + obj.PCustomerName);
                Console.WriteLine("Item qty is:" + obj.PItemQty);
                Console.WriteLine("Item price is :" + obj.PItemPrice);
                double amt = obj.GetOrderValue();
                Console.WriteLine(" value is:" + amt);
            }
                Console.ReadLine();
            
        }
    }
}
