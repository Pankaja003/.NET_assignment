﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Dll_Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number 1:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number 2:");
            int num2 = Convert.ToInt32(Console.ReadLine());
            CalculatorLibrary.Calculator dll = new CalculatorLibrary.Calculator();
            int sum = dll.Getsum(num1, num2);
            Console.WriteLine("sum is :" + sum);
            int sub = dll.Getsub(num1, num2);
            Console.WriteLine("sub is :" + sub);
            int mul = dll.GetMultiply(num1, num2);
            Console.WriteLine("mul is :" + mul);
            int div = dll.GetDivide(num1, num2);
            Console.WriteLine("div is :" + div);
            Console.ReadLine();



        }
    }
}
