﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj = new Employee(1, "abc", "rts", 30000, "yuuiu", "rteew", 5, 1234, "apo", 20);
            HR o1 = new HR();
            o1.Employee(obj);
            Account o2 = new Account();
            o2.Employee(obj);
            Manager o3 = new Manager();
            o3.Employee(obj);
            Console.ReadLine();
        }
    }
}
