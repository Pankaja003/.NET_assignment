﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Assignment
{
    class Manager
    {
        public void Employee(IManagerEmp e)
        {
            int id = e.GetEmployeeId();
            int exp = e.GetEmployeeExp();
            string projd = e.GetEmployeeProjDetails();
           
            Console.WriteLine("Employee id is:" + id);
            Console.WriteLine("Employee exp is:" + exp);
           Console.WriteLine("Employee proj details is:" + projd);
        }
    }
}
