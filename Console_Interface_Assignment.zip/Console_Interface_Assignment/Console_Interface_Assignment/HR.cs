﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Assignment
{
    class HR
    {
        public void Employee(IHREmp e)
        {
           
    
            int id = e.GetEmployeeId();
            string addr = e.GetEmployeeAddress();
            int salary = e.GetEmployeeSalary();
           
     Console.WriteLine("Employee id is:" + id);
            Console.WriteLine("Employee address is:" + addr);
            Console.WriteLine("Employee salary is:" + salary);
        }

    }
}
