﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Assignment
{
    class Employee:IHREmp,IAccountEmp,IManagerEmp
    {
        private int EmployeeId;
        private string EmployeeName;
        private string EmployeeCity;
        private int EmployeeSalary;
        private string EmployeeAddress;
        private string EmployeeProjDetails;
        private int EmployeeExp;
        private int EmployeeAccNo;
        private string EmployeeAccBankName;
        private int EmployeeAge;
        public Employee(int EmployeeId,string EmployeeName,string EmployeeCity,int EmployeeSalary,string EmployeeAddress,string EmployeeProjDetails,int EmployeeExp,int EmployeeAccNo,string EmployeeAccBankName,int EmployeeAge)
        {
            this.EmployeeId = EmployeeId;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeProjDetails = EmployeeProjDetails;
            this.EmployeeExp = EmployeeExp;
            this.EmployeeAccNo = EmployeeAccNo;
            this.EmployeeAccBankName = EmployeeAccBankName;
            this.EmployeeAge = EmployeeAge;

        }

        public string GetEmployeeAddress()
        {
            return this.EmployeeAddress;
        }

        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }

        public int GetEmployeeId()
        {
            return this.EmployeeId;
        }

        public int GetEmployeeAccNo()
        {
            return this.EmployeeAccNo;
        }

        public int GetEmployeeExp()
        {
            return this.EmployeeExp;
        }

        public string GetEmployeeProjDetails()
        {
            return this.EmployeeProjDetails;
        }
    }
}
