﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Assignment
{
    class Account
    {
        public void Employee(IAccountEmp e)
        {
          
            int id = e.GetEmployeeId();
            int salary = e.GetEmployeeSalary();
            int accno = e.GetEmployeeAccNo();
            Console.WriteLine("Employee id is:" + id);
            Console.WriteLine("Employee salary is:" + salary);

            Console.WriteLine("Employee accno is:" + accno);



        }
    }
}
