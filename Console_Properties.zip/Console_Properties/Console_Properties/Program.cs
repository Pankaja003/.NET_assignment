﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Properties
{
    class Program
    {
        static void Main(string[] args)
        {
            Student obj = new Student("abc", 55);
            
            Console.WriteLine(obj.PStudentId);
            Console.WriteLine(obj.PStudentName);
            Console.WriteLine(obj.PStudentMarks);

            obj.PStudentName = "XYZ";
            obj.PStudentMarks = 1001;
            Console.WriteLine(obj.PStudentName);
            Console.WriteLine(obj.PStudentMarks);
            obj.PStudentMarks = 45;
            Console.WriteLine(obj.PStudentMarks);
            Console.ReadLine();

        }
    }
}
