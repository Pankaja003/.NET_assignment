﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj = new Employee(1, "abc", 12, 3000);
            int id = obj.GetEmployeeID();
            string name = obj.GetEmployeeName();
            int age = obj.GetEmployeeAge();
            int salary = obj.GetEmployeeSalary();
            Console.WriteLine("ID is:" + id.ToString());
            Console.WriteLine("NAME is:" + name);
            Console.WriteLine("AGE is:" + age.ToString());
            Console.WriteLine("SALARY is:" + salary.ToString());
            obj.HappyBirthday();
            age = obj.GetEmployeeAge();
            Console.WriteLine("Current Age is:" + age);
            obj.GetSalaryIncrement(500);
            salary = obj.GetEmployeeSalary();
            Console.WriteLine("Incremented Salary is:" + salary);
            Console.ReadLine();

        }
    }
}
