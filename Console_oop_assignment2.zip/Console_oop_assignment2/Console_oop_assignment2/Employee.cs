﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_assignment2
{
    class Employee
    {
        private  int EmployeeId;
        private  string EmployeeName;
        private int EmployeeAge;
        private int EmployeeSalary;
        public Employee(int EmployeeId,string EmployeeName,int EmployeeAge,int EmployeeSalary)
        {
            this.EmployeeId = EmployeeId;
            this.EmployeeName = EmployeeName;
            this.EmployeeAge = EmployeeAge;
            this.EmployeeSalary = EmployeeSalary;
            Console.WriteLine("Objaect is Constructed");

        }

        public int GetEmployeeID()
        {
            return this.EmployeeId;
        }
        public string GetEmployeeName()
        {
            return this.EmployeeName;


        }
        public int GetEmployeeAge()
        {
            return this.EmployeeAge;
        }
        public void HappyBirthday( )
        {
            this.EmployeeAge = this.EmployeeAge + 1;

        }
        public void GetSalaryIncrement(int inc)
        {
            this.EmployeeSalary = this.EmployeeSalary + inc;

        }
        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }
    }
}
