﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_first_Application
{
    public partial class Frm_Newuser : Form
    {
        public Frm_Newuser()
        {
            InitializeComponent();
        }

        private void btn_Newuser_Click(object sender, EventArgs e)
        {
            if(txt_Name.Text==string.Empty)
            {
                MessageBox.Show("Enter Name");
            }
            else if(ddl_Cities.Text==string.Empty)
            {
                MessageBox.Show("Select city");
            }
            else if(rdb_Male.Checked==false&&rdb_Female.Checked==false)
                {
                MessageBox.Show("Select Gender");
            }
            else if(txt_Password.Text==string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                string name = txt_Name.Text;
                string emailid = txt_EmailId.Text;
                string city = ddl_Cities.Text;
                string gender = string.Empty;
                if(rdb_Male.Checked==true)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                string password = txt_Password.Text;
                //Database etc
                MessageBox.Show("User Created...");
            }
        }

        private void Frm_Newuser_Load(object sender, EventArgs e)
        {
            ddl_Cities.Items.Add("BGL");

            ddl_Cities.Items.Add("Kolkatta");
            ddl_Cities.Items.Add("UttarPradesh");
            ddl_Cities.Items.Add("Pune");
            ddl_Cities.Items.Add("Kerala");

        }

        private void dll_Cities_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
