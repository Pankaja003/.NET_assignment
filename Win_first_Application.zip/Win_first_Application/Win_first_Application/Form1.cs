﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_first_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if(txt_LoginID.Text==string.Empty)
            {
                MessageBox.Show("Enter your Login ID");
            }
            else if(txt_Password.Text==string.Empty)
            {
                MessageBox.Show("Enter your Password");
            }
            else
            {
                string loginID = txt_LoginID.Text;
                string password = txt_Password.Text;
                if(loginID=="User1"&& password=="pass@123")
                {
                    MessageBox.Show("Valid user");
                    Frm_Home obj = new Frm_Home();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("Invalid user");
                }
            }
        }

        private void btn_NewUser_Click(object sender, EventArgs e)
        {
            Frm_Newuser obj = new Frm_Newuser();
            obj.Show();
        }
    }
}
