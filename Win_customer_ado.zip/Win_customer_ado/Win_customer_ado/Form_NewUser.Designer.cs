﻿namespace Win_customer_ado
{
    partial class Form_NewUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Customername = new System.Windows.Forms.Label();
            this.lbl_CustomerPassword = new System.Windows.Forms.Label();
            this.lbl_City = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_mobileno = new System.Windows.Forms.Label();
            this.lbl_Emailid = new System.Windows.Forms.Label();
            this.txt_Customername = new System.Windows.Forms.TextBox();
            this.txt_EmployeePassword = new System.Windows.Forms.TextBox();
            this.txt_Address = new System.Windows.Forms.TextBox();
            this.txt_Mobileno = new System.Windows.Forms.TextBox();
            this.txt_EmailId = new System.Windows.Forms.TextBox();
            this.ddl_cities = new System.Windows.Forms.ComboBox();
            this.btn_NewUser = new System.Windows.Forms.Button();
            this.lbl_Status = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Customername
            // 
            this.lbl_Customername.AutoSize = true;
            this.lbl_Customername.Location = new System.Drawing.Point(88, 39);
            this.lbl_Customername.Name = "lbl_Customername";
            this.lbl_Customername.Size = new System.Drawing.Size(82, 13);
            this.lbl_Customername.TabIndex = 0;
            this.lbl_Customername.Text = "Customer Name";
            // 
            // lbl_CustomerPassword
            // 
            this.lbl_CustomerPassword.AutoSize = true;
            this.lbl_CustomerPassword.Location = new System.Drawing.Point(77, 82);
            this.lbl_CustomerPassword.Name = "lbl_CustomerPassword";
            this.lbl_CustomerPassword.Size = new System.Drawing.Size(100, 13);
            this.lbl_CustomerPassword.TabIndex = 1;
            this.lbl_CustomerPassword.Text = "Customer Password";
            // 
            // lbl_City
            // 
            this.lbl_City.AutoSize = true;
            this.lbl_City.Location = new System.Drawing.Point(107, 121);
            this.lbl_City.Name = "lbl_City";
            this.lbl_City.Size = new System.Drawing.Size(24, 13);
            this.lbl_City.TabIndex = 2;
            this.lbl_City.Text = "City";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Location = new System.Drawing.Point(108, 162);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(45, 13);
            this.lbl_Address.TabIndex = 3;
            this.lbl_Address.Text = "Address";
            // 
            // lbl_mobileno
            // 
            this.lbl_mobileno.AutoSize = true;
            this.lbl_mobileno.Location = new System.Drawing.Point(108, 196);
            this.lbl_mobileno.Name = "lbl_mobileno";
            this.lbl_mobileno.Size = new System.Drawing.Size(53, 13);
            this.lbl_mobileno.TabIndex = 4;
            this.lbl_mobileno.Text = "Mobile no";
            // 
            // lbl_Emailid
            // 
            this.lbl_Emailid.AutoSize = true;
            this.lbl_Emailid.Location = new System.Drawing.Point(107, 231);
            this.lbl_Emailid.Name = "lbl_Emailid";
            this.lbl_Emailid.Size = new System.Drawing.Size(40, 13);
            this.lbl_Emailid.TabIndex = 5;
            this.lbl_Emailid.Text = "Emailid";
            // 
            // txt_Customername
            // 
            this.txt_Customername.Location = new System.Drawing.Point(199, 36);
            this.txt_Customername.Name = "txt_Customername";
            this.txt_Customername.Size = new System.Drawing.Size(128, 20);
            this.txt_Customername.TabIndex = 6;
            this.txt_Customername.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txt_EmployeePassword
            // 
            this.txt_EmployeePassword.Location = new System.Drawing.Point(199, 82);
            this.txt_EmployeePassword.Name = "txt_EmployeePassword";
            this.txt_EmployeePassword.Size = new System.Drawing.Size(128, 20);
            this.txt_EmployeePassword.TabIndex = 7;
            this.txt_EmployeePassword.TextChanged += new System.EventHandler(this.txt_EmployeePassword_TextChanged);
            // 
            // txt_Address
            // 
            this.txt_Address.Location = new System.Drawing.Point(199, 159);
            this.txt_Address.Name = "txt_Address";
            this.txt_Address.Size = new System.Drawing.Size(128, 20);
            this.txt_Address.TabIndex = 8;
            // 
            // txt_Mobileno
            // 
            this.txt_Mobileno.Location = new System.Drawing.Point(199, 196);
            this.txt_Mobileno.Name = "txt_Mobileno";
            this.txt_Mobileno.Size = new System.Drawing.Size(128, 20);
            this.txt_Mobileno.TabIndex = 9;
            // 
            // txt_EmailId
            // 
            this.txt_EmailId.Location = new System.Drawing.Point(199, 231);
            this.txt_EmailId.Name = "txt_EmailId";
            this.txt_EmailId.Size = new System.Drawing.Size(128, 20);
            this.txt_EmailId.TabIndex = 10;
            // 
            // ddl_cities
            // 
            this.ddl_cities.FormattingEnabled = true;
            this.ddl_cities.Location = new System.Drawing.Point(199, 121);
            this.ddl_cities.Name = "ddl_cities";
            this.ddl_cities.Size = new System.Drawing.Size(128, 21);
            this.ddl_cities.TabIndex = 11;
            // 
            // btn_NewUser
            // 
            this.btn_NewUser.Location = new System.Drawing.Point(222, 271);
            this.btn_NewUser.Name = "btn_NewUser";
            this.btn_NewUser.Size = new System.Drawing.Size(75, 23);
            this.btn_NewUser.TabIndex = 12;
            this.btn_NewUser.Text = "New User";
            this.btn_NewUser.UseVisualStyleBackColor = true;
            this.btn_NewUser.Click += new System.EventHandler(this.btn_NewUser_Click);
            // 
            // lbl_Status
            // 
            this.lbl_Status.AutoSize = true;
            this.lbl_Status.Location = new System.Drawing.Point(108, 320);
            this.lbl_Status.Name = "lbl_Status";
            this.lbl_Status.Size = new System.Drawing.Size(63, 13);
            this.lbl_Status.TabIndex = 13;
            this.lbl_Status.Text = "Customer Id";
            // 
            // Form_NewUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 358);
            this.Controls.Add(this.lbl_Status);
            this.Controls.Add(this.btn_NewUser);
            this.Controls.Add(this.ddl_cities);
            this.Controls.Add(this.txt_EmailId);
            this.Controls.Add(this.txt_Mobileno);
            this.Controls.Add(this.txt_Address);
            this.Controls.Add(this.txt_EmployeePassword);
            this.Controls.Add(this.txt_Customername);
            this.Controls.Add(this.lbl_Emailid);
            this.Controls.Add(this.lbl_mobileno);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.lbl_City);
            this.Controls.Add(this.lbl_CustomerPassword);
            this.Controls.Add(this.lbl_Customername);
            this.Name = "Form_NewUser";
            this.Text = "Form_NewUser";
            this.Load += new System.EventHandler(this.Form_NewUser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Customername;
        private System.Windows.Forms.Label lbl_CustomerPassword;
        private System.Windows.Forms.Label lbl_City;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_mobileno;
        private System.Windows.Forms.Label lbl_Emailid;
        private System.Windows.Forms.TextBox txt_Customername;
        private System.Windows.Forms.TextBox txt_EmployeePassword;
        private System.Windows.Forms.TextBox txt_Address;
        private System.Windows.Forms.TextBox txt_Mobileno;
        private System.Windows.Forms.TextBox txt_EmailId;
        private System.Windows.Forms.ComboBox ddl_cities;
        private System.Windows.Forms.Button btn_NewUser;
        private System.Windows.Forms.Label lbl_Status;
    }
}