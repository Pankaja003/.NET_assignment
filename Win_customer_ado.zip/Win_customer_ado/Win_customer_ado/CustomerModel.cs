﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_customer_ado
{
    class CustomerModel
    {
        public int CustomerId{get; set; }
        public string Customername { get; set; }
        public string Customerpassword { get; set; }
        public string Customercity { get; set; }
        public string Customeraddr { get; set; }
        public string Customermobileno { get; set; }
        public string Customeremailid { get; set; }

    }
}
