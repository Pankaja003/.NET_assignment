﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;//DLL ref
using System.Data;//ado.net
using System.Data.SqlClient;//ado.net

namespace Win_customer_ado
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection
(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int Addcustomer(CustomerModel model)
        {
            try
            {
                SqlCommand com_addcustomer = new SqlCommand("proc_addcustomer", con);
                com_addcustomer.CommandType = CommandType.StoredProcedure;
                com_addcustomer.Parameters.AddWithValue("@name", model.Customername);
                com_addcustomer.Parameters.AddWithValue("@pwd", model.Customerpassword);
                com_addcustomer.Parameters.AddWithValue("@city", model.Customercity);
                com_addcustomer.Parameters.AddWithValue("@addr", model.Customeraddr);
                com_addcustomer.Parameters.AddWithValue("@mobileno", model.Customermobileno);
                com_addcustomer.Parameters.AddWithValue("@email", model.Customeremailid);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addcustomer.Parameters.Add(para_return);
                con.Open();
                com_addcustomer.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;

            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Login(int id, string password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);
                com_login.CommandType = CommandType.StoredProcedure;
                com_login.Parameters.AddWithValue("@id", id);
                com_login.Parameters.AddWithValue("@pwd", password);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(para_return);
                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;

                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


            }
        }

        public bool Updatecustomer(int id, string city,string addr, string mobileno)
        {
            try
            {
                SqlCommand com_update_customer = new SqlCommand("proc_Updatecustomer", con);
                com_update_customer.CommandType = CommandType.StoredProcedure;
                com_update_customer.Parameters.AddWithValue("@id", id);
                com_update_customer.Parameters.AddWithValue("@city", city);
                com_update_customer.Parameters.AddWithValue("@addr", addr);
                com_update_customer.Parameters.AddWithValue("@mobileno",mobileno);

                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_update_customer.Parameters.Add(para_return);
                con.Open();
                com_update_customer.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Deletecustomer(int id)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_deletecustomer", con);
                com_delete.CommandType = CommandType.StoredProcedure;
                com_delete.Parameters.AddWithValue("@id", id);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_delete.Parameters.Add(para_return);
                con.Open();
                com_delete.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        public CustomerModel Find(int id)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_findcustomer", con);
                com_find.CommandType = CommandType.StoredProcedure;
                com_find.Parameters.AddWithValue("@id", id);
                con.Open();
                SqlDataReader dr = com_find.ExecuteReader();
                if (dr.Read())
                {
                    CustomerModel model = new CustomerModel();
                    model.CustomerId = dr.GetInt32(0);
                    model.Customername = dr.GetString(1);
                    model.Customerpassword = dr.GetString(2);
                    model.Customercity = dr.GetString(3);
                    model.Customeraddr = dr.GetString(4);
                    model.Customermobileno = dr.GetString(5);
                    model.Customeremailid = dr.GetString(6);
                    con.Close();
                    return model;
                }
                con.Close();
                return null;

            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public List<CustomerModel> search(string key)
        {
            try
            {
                SqlCommand com_search = new SqlCommand("proc_searchcustomer", con);
                com_search.CommandType = CommandType.StoredProcedure;
                com_search.Parameters.AddWithValue("@key", key);
                con.Open();
                SqlDataReader dr = com_search.ExecuteReader();
                List<CustomerModel> customerlist = new List<CustomerModel>();
                while (dr.Read())
                {
                    CustomerModel model = new CustomerModel();
                    model.CustomerId = dr.GetInt32(0);
                    model.Customername = dr.GetString(1);
                    model.Customerpassword = dr.GetString(2);
                    model.Customercity = dr.GetString(3);
                    model.Customeraddr = dr.GetString(4);
                    model.Customermobileno = dr.GetString(5);
                    model.Customeremailid = dr.GetString(6);
                    customerlist.Add(model);
                }
                con.Close();
                return customerlist;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

    }
}
