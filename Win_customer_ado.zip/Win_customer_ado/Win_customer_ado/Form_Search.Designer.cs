﻿namespace Win_customer_ado
{
    partial class Form_Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CustomerKey = new System.Windows.Forms.Label();
            this.txt_Customerkey = new System.Windows.Forms.TextBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.dg_Customers = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Customers)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_CustomerKey
            // 
            this.lbl_CustomerKey.AutoSize = true;
            this.lbl_CustomerKey.Location = new System.Drawing.Point(29, 32);
            this.lbl_CustomerKey.Name = "lbl_CustomerKey";
            this.lbl_CustomerKey.Size = new System.Drawing.Size(71, 13);
            this.lbl_CustomerKey.TabIndex = 0;
            this.lbl_CustomerKey.Text = "Customer key";
            // 
            // txt_Customerkey
            // 
            this.txt_Customerkey.Location = new System.Drawing.Point(126, 32);
            this.txt_Customerkey.Name = "txt_Customerkey";
            this.txt_Customerkey.Size = new System.Drawing.Size(174, 20);
            this.txt_Customerkey.TabIndex = 1;
            // 
            // btn_Search
            // 
            this.btn_Search.Location = new System.Drawing.Point(344, 28);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(75, 23);
            this.btn_Search.TabIndex = 2;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // dg_Customers
            // 
            this.dg_Customers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Customers.Location = new System.Drawing.Point(32, 110);
            this.dg_Customers.Name = "dg_Customers";
            this.dg_Customers.Size = new System.Drawing.Size(430, 211);
            this.dg_Customers.TabIndex = 3;
            // 
            // Form_Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 343);
            this.Controls.Add(this.dg_Customers);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.txt_Customerkey);
            this.Controls.Add(this.lbl_CustomerKey);
            this.Name = "Form_Search";
            this.Text = "Form_Search";
            this.Load += new System.EventHandler(this.Form_Search_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_Customers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CustomerKey;
        private System.Windows.Forms.TextBox txt_Customerkey;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.DataGridView dg_Customers;
    }
}