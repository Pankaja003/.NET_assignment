﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_customer_ado
{
    public partial class Form_NewUser : Form
    {
        public Form_NewUser()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_NewUser_Click(object sender, EventArgs e)
        {

            if (txt_Customername.Text == string.Empty)
            {
                lbl_Status.Text = "Enter Customer Name";

            }
            else if (txt_EmployeePassword.Text == string.Empty)
            {
                lbl_Status.Text = "Enter Employee password";
            }
            else if (ddl_cities.Text == string.Empty)
            {
                lbl_Status.Text = "Select city";
            }
            else if (txt_Address.Text == string.Empty)
            {
                lbl_Status.Text = "Enter Address";
            }
            else if (txt_Mobileno.Text == string.Empty)
            {
                lbl_Status.Text = "Enter Mobileno";
            }
            else if (txt_EmailId.Text == string.Empty)
            {
                lbl_Status.Text = "Enter Emailid";
            }
            else
            {
                CustomerModel model = new CustomerModel();
                model.Customername = txt_Customername.Text;
                model.Customerpassword = txt_EmployeePassword.Text;
                model.Customercity = ddl_cities.Text;
                model.Customeraddr = txt_Address.Text;
                model.Customermobileno = txt_Mobileno.Text;
                model.Customeremailid = txt_EmailId.Text;
                CustomerDAL dal = new CustomerDAL();
                int id = dal.Addcustomer(model);
                lbl_Status.Text = "Customer Added, Id:" + id;
            }

        }

        private void txt_EmployeePassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form_NewUser_Load(object sender, EventArgs e)
        {

            ddl_cities.Items.Add("BGL");
            ddl_cities.Items.Add("chenni");
            ddl_cities.Items.Add("mumbai");
            ddl_cities.Items.Add("pune");
            ddl_cities.Items.Add("up");

        }
    }
}
