﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_customer_ado
{
    public partial class Form_Search : Form
    {
        public Form_Search()
        {
            InitializeComponent();
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string key = txt_Customerkey.Text;
            List<CustomerModel> list = dal.search(key);
            dg_Customers.DataSource = list;
        }

        private void Form_Search_Load(object sender, EventArgs e)
        {

        }
    }
}
