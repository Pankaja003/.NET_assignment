﻿namespace Win_customer_ado
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_LoginId = new System.Windows.Forms.Label();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.txt_LogInID = new System.Windows.Forms.TextBox();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.Login = new System.Windows.Forms.Button();
            this.btn_NewUser = new System.Windows.Forms.Button();
            this.lbl_Loginstatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_LoginId
            // 
            this.lbl_LoginId.AutoSize = true;
            this.lbl_LoginId.Location = new System.Drawing.Point(105, 56);
            this.lbl_LoginId.Name = "lbl_LoginId";
            this.lbl_LoginId.Size = new System.Drawing.Size(48, 13);
            this.lbl_LoginId.TabIndex = 0;
            this.lbl_LoginId.Text = "LogIn ID";
            this.lbl_LoginId.UseMnemonic = false;
            this.lbl_LoginId.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.Location = new System.Drawing.Point(100, 115);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(53, 13);
            this.lbl_Password.TabIndex = 1;
            this.lbl_Password.Text = "Password";
            // 
            // txt_LogInID
            // 
            this.txt_LogInID.Location = new System.Drawing.Point(238, 53);
            this.txt_LogInID.Name = "txt_LogInID";
            this.txt_LogInID.Size = new System.Drawing.Size(100, 20);
            this.txt_LogInID.TabIndex = 2;
            // 
            // txt_Password
            // 
            this.txt_Password.Location = new System.Drawing.Point(238, 112);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(100, 20);
            this.txt_Password.TabIndex = 3;
            // 
            // Login
            // 
            this.Login.Location = new System.Drawing.Point(78, 163);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(75, 23);
            this.Login.TabIndex = 4;
            this.Login.Text = "Login";
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // btn_NewUser
            // 
            this.btn_NewUser.Location = new System.Drawing.Point(263, 163);
            this.btn_NewUser.Name = "btn_NewUser";
            this.btn_NewUser.Size = new System.Drawing.Size(75, 23);
            this.btn_NewUser.TabIndex = 5;
            this.btn_NewUser.Text = "New User";
            this.btn_NewUser.UseVisualStyleBackColor = true;
            this.btn_NewUser.Click += new System.EventHandler(this.btn_NewUser_Click);
            // 
            // lbl_Loginstatus
            // 
            this.lbl_Loginstatus.AutoSize = true;
            this.lbl_Loginstatus.Location = new System.Drawing.Point(75, 225);
            this.lbl_Loginstatus.Name = "lbl_Loginstatus";
            this.lbl_Loginstatus.Size = new System.Drawing.Size(69, 13);
            this.lbl_Loginstatus.TabIndex = 6;
            this.lbl_Loginstatus.Text = "Login Status:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 261);
            this.Controls.Add(this.lbl_Loginstatus);
            this.Controls.Add(this.btn_NewUser);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.txt_LogInID);
            this.Controls.Add(this.lbl_Password);
            this.Controls.Add(this.lbl_LoginId);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_LoginId;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.TextBox txt_LogInID;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Button btn_NewUser;
        private System.Windows.Forms.Label lbl_Loginstatus;
    }
}

