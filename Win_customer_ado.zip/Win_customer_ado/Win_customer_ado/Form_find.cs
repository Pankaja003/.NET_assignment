﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_customer_ado
{
    public partial class Form_find : Form
    {
        public Form_find()
        {
            InitializeComponent();
        }

        private void Form_find_Load(object sender, EventArgs e)
        {

            ddl_cities.Items.Add("BGL");
            ddl_cities.Items.Add("chenni");
            ddl_cities.Items.Add("mumbai");
            ddl_cities.Items.Add("pune");
            ddl_cities.Items.Add("up");

        }

        private void btn_FindCustomer_Click(object sender, EventArgs e)
        {
            if (txt_CustomerID.Text == string.Empty)
            {
                lbl_CustomerStatus.Text = "enter the customer id";
            }
            else
            {
                int id = Convert.ToInt32(txt_CustomerID.Text);
                CustomerDAL dal = new CustomerDAL();
                CustomerModel model = dal.Find(id);
                if (model != null)
                {
                    txt_Customername.Text = model.Customername;
                   ddl_cities.Text = model.Customercity;
                    txt_Address.Text = model.Customeraddr;
                    txt_MobileNO.Text = model.Customermobileno;
                    txt_Emailid.Text = model.Customeremailid;
                 }
                else
                {
                    lbl_CustomerStatus.Text = "Customer not found";
                }
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_CustomerID.Text);
            string city = ddl_cities.Text;
            string addr = txt_Address.Text;
            string mobileno = txt_MobileNO.Text;  

            CustomerDAL dal = new CustomerDAL();
            bool status = dal.Updatecustomer(id, city, addr, mobileno);
            if (status == true)
            {
                lbl_CustomerStatus.Text = "Customer Updated";
            }
            else
            {
                lbl_CustomerStatus.Text = "Not found";
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_CustomerID.Text);
            CustomerDAL dal = new CustomerDAL();
            bool status = dal.Deletecustomer(id);
            if (status == true)
            {
                lbl_CustomerStatus.Text = "Deleted";
            }
            else
            {
                lbl_CustomerStatus.Text = "Not Deleted";
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

