﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_customer_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Login_Click(object sender, EventArgs e)
        {
            if (txt_LogInID.Text == string.Empty)
            {
                lbl_LoginId.Text = "Enter Login Id";
            }
            else if (txt_Password.Text == string.Empty)
            {
                lbl_Password.Text = "Enter your Password";
            }
            else
            {
                int loginID = Convert.ToInt32(txt_LogInID.Text);
                string password = txt_Password.Text;
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Login(loginID, password);
                if (status == true)
                {

                    Form_home obj = new Form_home();
                    obj.Show();
                }
                else
                {
                    lbl_Loginstatus.Text = "Invalid user Id or Password";
                }
            }
        }

        private void btn_NewUser_Click(object sender, EventArgs e)
        {
            Form_NewUser obj = new Form_NewUser();
            obj.Show();
        }
    }
}
