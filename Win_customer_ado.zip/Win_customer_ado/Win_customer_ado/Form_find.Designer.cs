﻿namespace Win_customer_ado
{
    partial class Form_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Customername = new System.Windows.Forms.Label();
            this.lbl_CustomerID = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_MobileNo = new System.Windows.Forms.Label();
            this.lbl_Emailid = new System.Windows.Forms.Label();
            this.txt_Customername = new System.Windows.Forms.TextBox();
            this.txt_CustomerID = new System.Windows.Forms.TextBox();
            this.txt_Address = new System.Windows.Forms.TextBox();
            this.txt_MobileNO = new System.Windows.Forms.TextBox();
            this.txt_Emailid = new System.Windows.Forms.TextBox();
            this.ddl_cities = new System.Windows.Forms.ComboBox();
            this.btn_FindCustomer = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.lbl_CustomerStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Customername
            // 
            this.lbl_Customername.AutoSize = true;
            this.lbl_Customername.Location = new System.Drawing.Point(53, 80);
            this.lbl_Customername.Name = "lbl_Customername";
            this.lbl_Customername.Size = new System.Drawing.Size(82, 13);
            this.lbl_Customername.TabIndex = 0;
            this.lbl_Customername.Text = "Customer Name";
            // 
            // lbl_CustomerID
            // 
            this.lbl_CustomerID.AutoSize = true;
            this.lbl_CustomerID.Location = new System.Drawing.Point(53, 37);
            this.lbl_CustomerID.Name = "lbl_CustomerID";
            this.lbl_CustomerID.Size = new System.Drawing.Size(65, 13);
            this.lbl_CustomerID.TabIndex = 1;
            this.lbl_CustomerID.Text = "Customer ID";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(70, 116);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(23, 13);
            this.lbl_city.TabIndex = 2;
            this.lbl_city.Text = "city";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Location = new System.Drawing.Point(63, 155);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(45, 13);
            this.lbl_Address.TabIndex = 3;
            this.lbl_Address.Text = "Address";
            // 
            // lbl_MobileNo
            // 
            this.lbl_MobileNo.AutoSize = true;
            this.lbl_MobileNo.Location = new System.Drawing.Point(63, 196);
            this.lbl_MobileNo.Name = "lbl_MobileNo";
            this.lbl_MobileNo.Size = new System.Drawing.Size(55, 13);
            this.lbl_MobileNo.TabIndex = 4;
            this.lbl_MobileNo.Text = "Mobile No";
            // 
            // lbl_Emailid
            // 
            this.lbl_Emailid.AutoSize = true;
            this.lbl_Emailid.Location = new System.Drawing.Point(68, 243);
            this.lbl_Emailid.Name = "lbl_Emailid";
            this.lbl_Emailid.Size = new System.Drawing.Size(40, 13);
            this.lbl_Emailid.TabIndex = 5;
            this.lbl_Emailid.Text = "Emailid";
            // 
            // txt_Customername
            // 
            this.txt_Customername.Location = new System.Drawing.Point(148, 80);
            this.txt_Customername.Name = "txt_Customername";
            this.txt_Customername.Size = new System.Drawing.Size(133, 20);
            this.txt_Customername.TabIndex = 6;
            // 
            // txt_CustomerID
            // 
            this.txt_CustomerID.Location = new System.Drawing.Point(148, 37);
            this.txt_CustomerID.Name = "txt_CustomerID";
            this.txt_CustomerID.Size = new System.Drawing.Size(133, 20);
            this.txt_CustomerID.TabIndex = 7;
            // 
            // txt_Address
            // 
            this.txt_Address.Location = new System.Drawing.Point(148, 155);
            this.txt_Address.Name = "txt_Address";
            this.txt_Address.Size = new System.Drawing.Size(133, 20);
            this.txt_Address.TabIndex = 8;
            // 
            // txt_MobileNO
            // 
            this.txt_MobileNO.Location = new System.Drawing.Point(148, 196);
            this.txt_MobileNO.Name = "txt_MobileNO";
            this.txt_MobileNO.Size = new System.Drawing.Size(133, 20);
            this.txt_MobileNO.TabIndex = 9;
            // 
            // txt_Emailid
            // 
            this.txt_Emailid.Location = new System.Drawing.Point(148, 236);
            this.txt_Emailid.Name = "txt_Emailid";
            this.txt_Emailid.Size = new System.Drawing.Size(133, 20);
            this.txt_Emailid.TabIndex = 10;
            this.txt_Emailid.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // ddl_cities
            // 
            this.ddl_cities.FormattingEnabled = true;
            this.ddl_cities.Location = new System.Drawing.Point(148, 116);
            this.ddl_cities.Name = "ddl_cities";
            this.ddl_cities.Size = new System.Drawing.Size(133, 21);
            this.ddl_cities.TabIndex = 11;
            // 
            // btn_FindCustomer
            // 
            this.btn_FindCustomer.Location = new System.Drawing.Point(394, 27);
            this.btn_FindCustomer.Name = "btn_FindCustomer";
            this.btn_FindCustomer.Size = new System.Drawing.Size(133, 39);
            this.btn_FindCustomer.TabIndex = 12;
            this.btn_FindCustomer.Text = "Find Customer";
            this.btn_FindCustomer.UseVisualStyleBackColor = true;
            this.btn_FindCustomer.Click += new System.EventHandler(this.btn_FindCustomer_Click);
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(73, 298);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(81, 23);
            this.btn_Update.TabIndex = 13;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(221, 297);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(83, 23);
            this.btn_Delete.TabIndex = 14;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // lbl_CustomerStatus
            // 
            this.lbl_CustomerStatus.AutoSize = true;
            this.lbl_CustomerStatus.Location = new System.Drawing.Point(73, 356);
            this.lbl_CustomerStatus.Name = "lbl_CustomerStatus";
            this.lbl_CustomerStatus.Size = new System.Drawing.Size(87, 13);
            this.lbl_CustomerStatus.TabIndex = 15;
            this.lbl_CustomerStatus.Text = "Customer Status:";
            // 
            // Form_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 387);
            this.Controls.Add(this.lbl_CustomerStatus);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_FindCustomer);
            this.Controls.Add(this.ddl_cities);
            this.Controls.Add(this.txt_Emailid);
            this.Controls.Add(this.txt_MobileNO);
            this.Controls.Add(this.txt_Address);
            this.Controls.Add(this.txt_CustomerID);
            this.Controls.Add(this.txt_Customername);
            this.Controls.Add(this.lbl_Emailid);
            this.Controls.Add(this.lbl_MobileNo);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_CustomerID);
            this.Controls.Add(this.lbl_Customername);
            this.Name = "Form_find";
            this.Text = "Form_find";
            this.Load += new System.EventHandler(this.Form_find_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Customername;
        private System.Windows.Forms.Label lbl_CustomerID;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_MobileNo;
        private System.Windows.Forms.Label lbl_Emailid;
        private System.Windows.Forms.TextBox txt_Customername;
        private System.Windows.Forms.TextBox txt_CustomerID;
        private System.Windows.Forms.TextBox txt_Address;
        private System.Windows.Forms.TextBox txt_MobileNO;
        private System.Windows.Forms.TextBox txt_Emailid;
        private System.Windows.Forms.ComboBox ddl_cities;
        private System.Windows.Forms.Button btn_FindCustomer;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Label lbl_CustomerStatus;
    }
}