﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorLibrary
{
    public class Calculator
    {
        public int Getsum(int n1,int n2)
        {
            int sum = n1 + n2;
            return sum;
        }
        public int Getsub(int n1, int n2)
        {
            int sub = n1 - n2;
            return sub;
        }

        public int GetMultiply(int n1, int n2)
        {
            int mul = n1 * n2;
            return mul;
        }

        public int GetDivide(int n1, int n2)
        {
            int div = n1 /n2;
            return div;
        }

    }
}
