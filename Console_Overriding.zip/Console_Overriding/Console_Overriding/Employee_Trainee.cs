﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Employee_Trainee:Employee
    {
        public Employee_Trainee(string EmployeeName, double EmployeeSalary)
            :base(EmployeeName,EmployeeSalary)
        {
            Console.WriteLine("Employee Trainee Object is Created");

        }
        public sealed override double GetSalary(int Days)//sealed stops the next overridding
        {
            return this.EmployeeSalary;
        }
    }
}
