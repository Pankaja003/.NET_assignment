﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Employee
    {
        private int EmployeeId;
        private string EmployeeName;
        protected double EmployeeSalary;
        private static int count = 1000;
        public Employee(string EmployeeName,double EmployeeSalary)
        {
            this.EmployeeId = ++Employee.count;
            this.EmployeeName = EmployeeName;
            this.EmployeeSalary = EmployeeSalary;
        }
        public int PEmployeeID
        {
            get
            {
                return this.EmployeeId;
            }
        }
        public string PEmployeeName
        {
            get
            {
                return this.EmployeeName;
            }
        }
        public double PEmployeeSalary
        {
            get
            {
                return this.EmployeeSalary;
            }
        }
        public string GetWork()
        {
            return "Dotnet Developer";
        }
        public virtual double GetSalary(int Days)
        {
            int bonus = 2000;
            double tds = this.EmployeeSalary * .1;
            double salary = this.EmployeeSalary / 30 * Days + bonus - tds;
            return salary;
        }
    }
}
