﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter your Salary:");

        
            double salary = Convert.ToDouble(Console.ReadLine());


            Console.WriteLine("Enter the type of employee:");
            string type = Console.ReadLine();


            Employee obj = null;
            if(type=="Employee")
            {
                obj= new Employee(name, salary);
            }
            else if(type=="Contract")
            {
                obj = new Employee_Contract(name, salary);

            }
            else
            {
                obj = new Employee_Trainee(name, salary);
            }
            if (obj != null)

            {



                Console.WriteLine("EmployeeId is:" + obj.PEmployeeID);
                Console.WriteLine("Employee Name is:" + obj.PEmployeeName);
                Console.WriteLine("Employee Basic Salary:" + obj.PEmployeeSalary);

                string work = obj.GetWork();
                Console.WriteLine("Work Details:" + work);

                Console.WriteLine("Enter The Number of days:");
                int days = Convert.ToInt32(Console.ReadLine());

                double monthlysalary = obj.GetSalary(days);
                Console.WriteLine("Month Salary is:" + monthlysalary);
            }
            Console.ReadLine();
        }
    }
}
