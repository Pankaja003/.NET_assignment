﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Employee_Contract:Employee
    {
        public Employee_Contract(string EmployeeName,double EmployeeSalary)
             :base(EmployeeName,EmployeeSalary)
        {
            Console.WriteLine("Employee contract object Constructed");
        }
        public  override double GetSalary(int days)
        {
            double salary = this.EmployeeSalary / 30 * days;
            return salary;
        }
    }
}
