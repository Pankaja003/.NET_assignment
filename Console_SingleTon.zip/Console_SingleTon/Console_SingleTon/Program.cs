﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_SingleTon
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager m1 = Manager.GetManagerObject();
            Manager m2 = Manager.GetManagerObject();
            Console.WriteLine(m1.PManagerId);
            Console.WriteLine(m2.PManagerName);
            if(m1==m2)
            {
                Console.WriteLine("Single Ton Object");
            }
            else
            {
                Console.WriteLine("Not Single Ton Object");
            }
            Console.ReadLine();
        }
    }
}
