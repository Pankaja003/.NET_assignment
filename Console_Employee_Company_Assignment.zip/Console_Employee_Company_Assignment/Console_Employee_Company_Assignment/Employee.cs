﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_Company_Assignment
{
    class Employee
    {
        public delegate void delleave(int EmployeeId, string msg);
        public event delleave evtleave;
        private int EmployeeId;
        private string EmployeeName;
        private string EmployeeCity;
        private static int count;
        public Employee(string EmployeeName,string EmployeeCity)
        {
            this.EmployeeId =++Employee.count;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
        }
        public int PEmployeeId
        {
            get
            {
                return this.EmployeeId;
            }
        }
        public string PEmployeeName
        {
            get
            {
                return this.EmployeeName;
            }
        }
        public string PEmployeeCity
        {
            get
            {
                return this.EmployeeCity;
            }
        }
        public void RequestLeave(string LeaveReason)
        {
            Console.WriteLine("Employee Request For Live:" + LeaveReason);
            if(this.evtleave!=null)
            {
                this.evtleave(this.EmployeeId, LeaveReason);
            }
        }
            
    }
}
