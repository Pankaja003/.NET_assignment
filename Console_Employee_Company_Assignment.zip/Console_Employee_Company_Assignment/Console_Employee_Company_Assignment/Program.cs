﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_Company_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Company cobj = new Company("abc", "hklvhjkl");
            Console.WriteLine("Company name is:" + cobj.PCompanyName);
            Console.WriteLine("Company City is:" + cobj.PCompanyCity);
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1-Add,2-Search,3-ShowAll,4-Remove,5-RequestLeave,6-exit");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch(opt)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter the Employee Name is:");
                            string name = Console.ReadLine();
                            Console.WriteLine("Enter the Employee city:");
                            string city =Console.ReadLine();
                            Employee e = new Employee(name, city);
                            cobj.AddEmployee(e);
                            Console.WriteLine("Employee is Added:" + e.PEmployeeId);
                            break;

                        }
                    case 2:
                        {
                            Console.WriteLine("Enter the EmployeeId:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee e = cobj.SearchEmployee(id);
                            if(e!=null)
                            {
                                Console.WriteLine( e.PEmployeeId+"   "+ e.PEmployeeName + "   " + e.PEmployeeCity);

                            }
                            else
                            {
                                Console.WriteLine("Employee Not Found");
                            }

                            break;

                        }
                    case 3:
                        {
                            cobj.ShowEmployee();
                            break;
                        }

                    case 4:
                        {
                            Console.WriteLine("Enter the Employee id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            bool status = cobj.Remove(id);
                            if(status==true)
                            {
                                Console.WriteLine("Removed Successfully");

                            }
                            else
                            {
                                Console.WriteLine("Not Found");
                            }
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Enter the Employee id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee e = cobj.SearchEmployee(id);
                            if(e!=null)
                            {
                                Console.WriteLine("Enter the Reson for Leave:");
                                string reason = Console.ReadLine();
                                e.RequestLeave(reason);
                            }
                            else
                            {
                                Console.WriteLine("Not Found");

                            }
                            break;
                        }
                    case 6:
                        {
                            flag = false;
                            break;
                        }
                }

            }
            
        }

    }
}
