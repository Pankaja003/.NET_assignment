﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee_Company_Assignment
{
    class Company
    {   
        public void LeaveNotify(int EmployeeId,string reason)
        {
            Console.WriteLine("Company Portal: Employee is on Leave,ID" +EmployeeId+ ",Reason" +reason);
        }
        private string CompanyName;
        private string CompanyCity;
        private List<Employee> EmployeeList = new List<Employee>();
        public Company(string CompanyName,string CompanyCity)
        {
            this.CompanyName = CompanyName;
            this.CompanyCity = CompanyCity;
        }
        public string PCompanyName
        {
            get
            {
                return this.CompanyName;
            }
        }
        public string PCompanyCity
        {
            get
            {
                return this.CompanyCity;
            }
        }

        public void AddEmployee(Employee obj)
        {
            this.EmployeeList.Add(obj);
            obj.evtleave += new Employee.delleave(this.LeaveNotify);//binding
        }

        public Employee SearchEmployee(int id)
        {
            foreach(Employee e in EmployeeList)
            {
                if(e.PEmployeeId==id)
                {
                    return e;
                }
            }
            return null;
        }
        public bool Remove(int id)
        {
            foreach(Employee e in EmployeeList)
            {
                if(e.PEmployeeId==id)
                {
                    this.EmployeeList.Remove(e);
                    return true;
                }
            }
            return false;
        }
        public void ShowEmployee()
        {
            foreach(Employee e in this.EmployeeList)
            {
                Console.WriteLine("Employee Id is:"+ e.PEmployeeId+"\t Employee Name is:" + e.PEmployeeId + "\t Employee city is:" + e.PEmployeeCity);

            }
        }
    }
}
