﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Inheritance
{
    sealed class Customer_Online:Customer
    {
        private string PaymentType;
        private string DelivaryAddress;
        public Customer_Online(string CustomerNumber,string CustomerName,int CustomerAge,string PaymentType,string DelivaryAddress)
            :base(CustomerNumber,CustomerName,CustomerAge)
        {
            this.PaymentType = PaymentType;
            this.DelivaryAddress = DelivaryAddress;
            Console.WriteLine("Child Class Object Constructor");
        }
        public string PPaymentType
        {
            get
            {
                return this.PaymentType;
            }
        }
        public string PDelivaryAddress
        {
            get
            {
                return this.DelivaryAddress;
            }
        }
            
    }
}
