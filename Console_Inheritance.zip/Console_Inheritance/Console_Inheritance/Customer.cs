﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Inheritance
{
    class Customer//:objet
    {
        protected string CustomerNumber;
        protected string CustomerName;
        protected int CustomerAge;
        public Customer(string CustomerNumber,string CustomerName,int CustomerAge)
        {
            this.CustomerNumber = CustomerNumber;
            this.CustomerName = CustomerName;
            this.CustomerAge = CustomerAge;
            Console.WriteLine("Parent Class Object Constructor");

        }
        public string PCustomerNumber
        {
            get
            {
                return this.CustomerNumber;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;

            }
        }
        public int PCustomerAge
        {
            get
            {
                return this.CustomerAge;
            }
        }
    }
}
