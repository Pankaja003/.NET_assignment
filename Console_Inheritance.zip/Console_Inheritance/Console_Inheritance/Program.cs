﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Customer obj = new Customer("7254690899", "ffgdg", 89);
             Console.WriteLine(obj.PCustomerNumber);
             Console.WriteLine(obj.PCustomerName);
             Console.WriteLine(obj.PCustomerAge);*/
            Customer obj1 =new Customer_Online("78989890", "ghhdg", 56, "COD", "hhyytr");
            Customer_Online obj = obj1 as Customer_Online;
            Console.WriteLine(obj.PCustomerNumber);
            Console.WriteLine(obj.PCustomerName);
            Console.WriteLine(obj.PCustomerAge);
            Console.WriteLine(obj.PPaymentType);
            Console.WriteLine(obj.PDelivaryAddress);
            

            Console.ReadLine();
        }
    }
}
