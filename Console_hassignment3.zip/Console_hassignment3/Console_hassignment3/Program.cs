﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hassignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 2, 4, 68, 78, 5 };
            for (int i1 = 0; i1 < arr.Length; i1++)
            {
               int count = 0;
                 int num = arr[i1];
                for (int i = 1; i <= num / 2; i++)
                {if (num % i == 0)
                    {count++;
                    } }
                if (count == 1)
                {   Console.WriteLine("Prime number:" + arr[i1]);
                }
                else
                {  Console.WriteLine("Not Prime number:" + arr[i1]);
                }
                }
            Console.ReadLine();





        }
    }
}
