﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class College
    {
        public void LeaveNotify(int StudentId,string reason)//E
        {
            Console.WriteLine("College Portal: Student is On Leave,Id:" + StudentId + ",Reason:" + reason);
        }
        private int CollegeId;
        private string CollegeName;
        private List<Student> Studentlist = new List<Student>();
        public College(int CollegeId, string CollegeName)
        {
            this.CollegeId = CollegeId;
            this.CollegeName = CollegeName;
        }
        public int PCollegeId
        {
            get
            {
                return this.CollegeId;
            }
        }

        public string PCollegeName
        {
            get
            {
                return this.CollegeName;
            }
        }
        public void AddStudent(Student obj)
        {
            this.Studentlist.Add(obj);
            obj.evtleave += new Student.delleave(this.LeaveNotify);//Binding
        }
        public Student FindStudent(int id)
        {
            foreach(Student s in Studentlist)
            {
                if(s.PStudentId==id)
                {
                    return s;
                }
            }
            return null;
        }
        public bool Remove(int id)
        {
            foreach(Student s in Studentlist)
            {
                if(s.PStudentId==id)
                {
                    this.Studentlist .Remove(s);
                    return true;
                }
            }
            return false;
            }
        public void  ShowAll()
        {
            foreach(Student s in this.Studentlist)
            {
                Console.WriteLine("Student id is:" + s.PStudentId
                    + "\t Student  Name:" + s.PStudentName);
            }
        }
    }
}
