﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class Program
    {
        static void Main(string[] args)
        {
            College cobj = new College(1001, "Pathfront");
            Console.WriteLine("College ID:" + cobj.PCollegeId);
            Console.WriteLine("College Name is:" + cobj.PCollegeName);
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1-Add,2-Find,3-ShowAll,4-Remove,5-RequestLeave,6-exit");
                int opt = Convert.ToInt32(Console.ReadLine());
                   
                switch(opt)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter the student name:");
                            string name = Console.ReadLine();
                            Console.WriteLine("Enter the Student  email id:");
                            string emailid = Console.ReadLine();
                            Student s = new Student(name, emailid);
                            cobj.AddStudent(s);
                            Console.WriteLine("student Added:" + s.PStudentId);
                            break;
          

                        }
                    case 2:
                        {
                            Console.WriteLine("Enter the StudentId:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Student s = cobj.FindStudent(id);
                            if(s!=null)
                            {
                                Console.WriteLine(s.PStudentId + " " + s.PStudentName + " " +s.PStudentEmailId);
                            }
                            else
                            {
                                Console.WriteLine("Student Not Found");
                            }
                            break;
                        }
                    case 3:
                        {
                            cobj.ShowAll();
                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("Enter the Student Id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            bool status = cobj.Remove(id);
                            if(status==true)
                            {
                                Console.WriteLine("Removed Successfully");
                            }
                            else
                            {
                                Console.WriteLine("Not Found");
                            }
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Enter the studnt id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Student s = cobj.FindStudent(id);
                            if(s!=null)
                            {
                                Console.WriteLine("Enter the Leave Reason:");
                                string reason = Console.ReadLine();
                                s.RequestLeave(reason);
                            }
                            else
                            {
                                Console.WriteLine("Not Found");
                            }
                            break;

                      
                        }
                    case 6:
                        {
                            flag = false;
                            break;
                        }

                }
            }

        }
    }
}
