﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class Student
    {
        public delegate void delleave(int StudentId, string msg);
        public event delleave evtleave;//member of class (object member)
        private int StudentId;
        private string StudentName;
        private string StudentEmailId;
        private static int count;
        public Student(string StudentName,string StudentEmailId)
        {
            this.StudentId = ++Student.count;
            this.StudentName = StudentName;
            this.StudentEmailId = StudentEmailId;
        }
        public  int PStudentId
        {
            get
            {
                return this.StudentId;
            }
        }
        public string PStudentName
        {
            get
            {
                return this.StudentName;
            }
        }
        public string PStudentEmailId
        {
            get
            {
                return this.StudentEmailId;
            }
        }
        public void RequestLeave(string LeaveReason)
        {
            Console.WriteLine("Student Request for a leave:" + LeaveReason);
            if(this.evtleave!=null)
            {
                this.evtleave(this.StudentId, LeaveReason);
            }
        }
    }
}
