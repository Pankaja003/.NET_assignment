﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Win_Multithreading_assignment
{
    class Calc
    {
        public Task<double> GetCalc(double d1,double d2,OperationType opt)
        {
            Task<double> t = Task.Run(() =>
              {
                  Thread.Sleep(5000);
                  double result = 0;
                  if(opt==OperationType.add)
                  {
                      result = d1 + d2;
                  }
                  else if(opt==OperationType.sub)
                  {
                      result = d1 - d2;
                  }
                  else if(opt==OperationType.mul)
                  {
                      result = d1 * d2;
                  }
                  else if(opt==OperationType.div)
                  {
                      result = d1 / d2;
                  }
                  return result;

              });
            return t;
        }
    }
    enum OperationType
    {
        add,sub,mul,div
    }
}
