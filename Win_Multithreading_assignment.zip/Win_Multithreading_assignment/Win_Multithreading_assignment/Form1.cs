﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_Multithreading_assignment
{
    public partial class Form1 : Form
    {
        Calc obj = new Calc();
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private async void btn_Addition_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_Num1.Text);
            double d2 = Convert.ToDouble(txt_Num2.Text);
            Task<double> t = obj.GetCalc(d1, d2, OperationType.add);
            double r = await t;
            lst_Results.Items.Add("Result :" + r);
        }

        private async void btn_Substraction_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_Num1.Text);
            double d2 = Convert.ToDouble(txt_Num2.Text);
            Task<double> t = obj.GetCalc(d1, d2, OperationType.sub);
            double r = await t;
            lst_Results.Items.Add("Result :" + r);

        }

        private async void btn_multiply_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_Num1.Text);
            double d2 = Convert.ToDouble(txt_Num2.Text);
            Task<double> t = obj.GetCalc(d1, d2, OperationType.mul);
            double r = await t;
            lst_Results.Items.Add("Result :" + r);


        }

        private async void btn_division_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_Num1.Text);
            double d2 = Convert.ToDouble(txt_Num2.Text);
            Task<double> t = obj.GetCalc(d1, d2, OperationType.div);
            double r = await t;
            lst_Results.Items.Add("Result :" + r);

        }
    }
}
