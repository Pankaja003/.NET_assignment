﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Reflection
{
    class XYZ
    {
        [Obsolete("It is not in use,instead use GetCall Function",true)]
        public void Call()
        {
            Console.WriteLine("Call");
        }

        public void GetCall()
        {
            Console.WriteLine("new GetCall Function");
        }
    }
}
