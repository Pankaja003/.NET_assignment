﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Console_Reflection
{
    class Program
    {
        static void Main(string[] args)
        {

            XYZ obj = new XYZ();
            obj.GetCall();


           /* Type t = typeof(Test);
            Console.WriteLine(t.Assembly.FullName);
            Console.WriteLine(t.FullName);
            MethodInfo[] m = t.GetMethods();
            foreach(MethodInfo method in m)
            {
                Console.WriteLine(method.Name);
            }

            object obj = Activator.CreateInstance(t);
            foreach(MethodInfo meth in m)
            {
                if(meth.GetParameters().Length==0)
                {
                    object ret = meth.Invoke(obj, null);
                    Console.WriteLine("Return Value" + ret);
                }
            }*/




            Console.ReadLine();

        }
    }
}
