﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Reflection
{
    class Test
    {
        public string GetData1()
        {
            return "GetData1";
        }
        public string GetData2()
        {
            return "GetData2";
        }
        public string GetData3()
        {
            return "GetData3";
        }
    }
}
