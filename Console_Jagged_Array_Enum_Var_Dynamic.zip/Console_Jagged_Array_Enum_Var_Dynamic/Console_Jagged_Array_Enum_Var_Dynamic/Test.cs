﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Jagged_Array_Enum_Var_Dynamic
{
    class Test
    {
        public int? i;//nullable type
        public bool? status;//false
        public string name;//null
    }
}
