﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_assignment1
{
    class Account
    {
        private int AccountId;
        private string AccountName;
        private int AccountBal;

       public Account(int AccountId,string AccountName,int AccountBal)
        {
            this.AccountId = AccountId;
            this.AccountName = AccountName;
            this.AccountBal = AccountBal;
            Console.WriteLine("Object is Constructed");
        }
        public int GetAccountId()
        {
            return this.AccountId;
        }
        public string GetName()
        {
            return this.AccountName;

        }
        public void Deposite(int amt)
        {
           
            this.AccountBal = this.AccountBal +amt;
        }
        public void Withdraw(int amt)
        {
            
            this.AccountBal = this.AccountBal-amt;
        }
        public int GetBal()
        {
            return this.AccountBal;
        }
      

    }
}
