﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Account obj = new Account(1, "abc", 3000);
            int Id = obj.GetAccountId();
            string Name = obj.GetName();
            int Bal = obj.GetBal();

            Console.WriteLine("CustomerId:" + Id.ToString());
            Console.WriteLine("CustomerName:" + Name);
            Console.WriteLine("CustomerBal:" + Bal.ToString());
            obj.Deposite(4000);
            Bal = obj.GetBal();
            Console.WriteLine(" deposited:" + Bal );
            obj.Withdraw(500);
            Bal = obj.GetBal();
            Console.WriteLine("Withdrawed:" + Bal);
            Account obj1 = new Account(2, "xyz", 5000);
            int Id1 = obj1.GetAccountId();
            string Name1 = obj1.GetName();
            int Bal1 = obj1.GetBal();

            Console.WriteLine("CustomerId:" + Id1.ToString());
            Console.WriteLine("CustomerName:" + Name1);
            Console.WriteLine("CustomerBal:" + Bal1.ToString());
            obj1.Deposite(4000);
            Bal1 = obj1.GetBal();
            Console.WriteLine(" deposited:" + Bal1);
            obj1.Withdraw(500);
            Bal1 = obj1.GetBal();
            Console.WriteLine("Withdrawed:" + Bal1);


            Console.ReadLine();


                


        }
    }
}
