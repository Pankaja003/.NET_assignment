﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hassignment2
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the number:");
            int num = Convert.ToInt32(Console.ReadLine());
             int count = 0;
            for (int i = 1; i <= num / 2; i++)
                   {
                    if (num % i == 0)
                    {
                        count++;
                    }
                }
                if (count == 1)
                {
                    Console.WriteLine("Prime number:" );
                }
                else
                {
                    Console.WriteLine("Not Prime number:" );
                }


            
            Console.ReadLine();

        }
    }
}
