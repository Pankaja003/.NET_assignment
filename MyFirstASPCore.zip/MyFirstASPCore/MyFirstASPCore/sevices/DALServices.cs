﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace MyFirstASPCore.sevices
{
    public class DALServices:IDALService
    {

        IConfiguration configuration;
        SqlConnection con;
        public DALServices(IConfiguration configuration)
        {
            this.configuration = configuration;
            con = new SqlConnection(this.configuration["constr"]);
        }
        public string getdetails()
        {
            string str = this.configuration["constr"];
            return "Hello from DAL:" + str;
        }

    }
}
