﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyFirstASPCore.sevices
{
    public interface IDALService
    {
        string getdetails();
    }
}
