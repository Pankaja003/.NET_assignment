﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop2
{
    class Student
    {
        private readonly int StudentID;
        private string StudentName;
        private int StudentMarks;
        public Student(int StudentID,string StudentName,int StudentMarks)
            :this(StudentID,StudentName)
        {
            
            this.StudentMarks = StudentMarks;
            Console.WriteLine("Three Parameter Consturctor");
        }
        public Student(int StudentID,string StudentName)
        {
            this.StudentID = StudentID;
            this.StudentName = StudentName;
            Console.WriteLine("Two  Parameter Constructor ");
        }            
           
       

    }
}
