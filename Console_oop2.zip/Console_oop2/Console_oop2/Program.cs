﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop2
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Student obj = new Student(1, "abc",90);
            
            Console.ReadLine();
           
        }
    }
}
