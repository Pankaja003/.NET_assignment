﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop1
{
    class Customer
    {
        private int CustomerID;
        private string CustomerName;
        private int CustomerAge;
        private string CustomerCity;
        public Customer(int CustomerID,String CustomerName,int CustomerAge,string CustomerCity)
        {
            this.CustomerID = CustomerID;
            this.CustomerName = CustomerName;
            this.CustomerAge = CustomerAge;
            this.CustomerCity = CustomerCity;
            Console.WriteLine("Object Constructor called");
        }
        

        public string GetName()
        {
            return this.CustomerName;
        }
        public string GetCity()
        {
            return this.CustomerCity;
        }
        public int GetAge()
        {
            return this.CustomerAge;
        }
        public void UpdateAge(int age)
        {
            this.CustomerAge = age;
        }
    }
}
