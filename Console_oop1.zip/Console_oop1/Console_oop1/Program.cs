﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop1
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer obj = new Customer(1, "ABC", 21, "BGL");
            string name = obj.GetName();
            string city = obj.GetCity();
            int age = obj.GetAge();
            Console.WriteLine("NAME :" + name);
            Console.WriteLine("CITY :" + city);
            Console.WriteLine("AGE:" + age.ToString());
            obj.UpdateAge(30);
            age = obj.GetAge();
            Console.WriteLine("Updated Age is:" + age.ToString());
            Console.ReadLine();

        }
    }
}
