﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] marks = { 20, 40, 24, 60, 45 };
            int max = marks[0];
            int min = marks[0];
            for(int i=0;i<marks.Length;i++)
            {
                Console.WriteLine(marks[i]);
         
            }
            int sum = 0;
            for (int i = 0; i < marks.Length; i++)
            {
                sum = sum + marks[i];
            }

                Console.WriteLine("Sum is :" + sum);

                for (int i=1;i<marks.Length;i++)
            {
                if(marks[i]>max)
                {
                    max = marks[i];
                }
                if(marks[i]<min)
                {
                    min = marks[i];
                }
            }

            Console.WriteLine("MAX :" + max);
            Console.WriteLine("MIN :" + min);
            int temp = marks[0];
            marks[0] = marks[marks.Length - 1];
            marks[marks.Length - 1] = temp;
            for(int i=0;i<marks.Length;i++)
            {
                Console.WriteLine(marks[i]);
            }
            
            Console.ReadLine();
        }
    }
}
