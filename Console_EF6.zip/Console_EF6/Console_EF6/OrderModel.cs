﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace Console_EF6
{
    [Table("tbl_Orders")]

    class OrderModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
         public int OrderId { get; set; }
        [Required]
        public int CustomerId { get; set; }
        [Required]
        public string ItemName { get; set; }
        [Required]
        public int ItemQty { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime OrderDate { get; set; }
        [ForeignKey(" CustomerId")]
        public CustomerModel Customers { get; set; }
    }
}
