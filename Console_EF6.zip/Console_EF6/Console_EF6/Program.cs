﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_EF6
{
    class Program
    {
        static void Main(string[] args)
        { //ADD

            MydbContext dc = new MydbContext();
            /* CustomerModel model = new CustomerModel();
             model.CustomerName = "Jhon1";
             model.CustomerCity = "BGL1";
             model.CustomerEmail = "jhon1@gmail.com";
             dc.Customers.Add(model);
             dc.SaveChanges();//Update Datbase
             Console.WriteLine("Customer Added :" + model.CustomerID);

     */

            //Read
            // CustomerModel model = (from c in dc.Customers
            //                       where c.CustomerID == 1
            //                     select c).FirstOrDefault();//LINQ

            /*    CustomerModel model = dc.Customers.FirstOrDefault(c => c.CustomerID == 2);
                if (model != null)
                {
                    Console.WriteLine(model.CustomerID + " " + model.CustomerName);
                    //dc.Customers.Remove(model);
                    // model.CustomerCity = "Pune";
                    //dc.SaveChanges();//Update
                    //Console.WriteLine("Delete");
                }
                else
                {
                    Console.WriteLine("Not Found");
                }
                */

            var count = dc.Customers.Count(c => c.CustomerID == 1 && c.CustomerName == "Jhon");

            Console.WriteLine(count);
            var list1 = (from c in dc.Customers
                         where c.CustomerCity == "Chenni"
                         select c).ToList();
            string key = "BGL";
            var list2 = dc.Customers.Where
                (c => c.CustomerCity.Contains(key) || c.CustomerEmail.Contains(key)).ToList();
            foreach(CustomerModel m in list2)
            {
                Console.WriteLine(m.CustomerID + " " + m.CustomerName);
            }
            Console.ReadLine();
        
        }

    }
}
