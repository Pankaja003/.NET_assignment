namespace Console_EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DB2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tbl_Customers", "CustomerEmail", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tbl_Customers", "CustomerEmail");
        }
    }
}
