namespace Console_EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DB1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tbl_Customers",
                c => new
                    {
                        CustomerID = c.Int(nullable: false, identity: true),
                        CustomerFullName = c.String(nullable: false, maxLength: 100),
                        CustomerCity = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.CustomerID);
            
            CreateTable(
                "dbo.tbl_Orders",
                c => new
                    {
                        OrderId = c.Int(nullable: false, identity: true),
                        CustomerId = c.Int(nullable: false),
                        ItemName = c.String(nullable: false),
                        ItemQty = c.Int(nullable: false),
                        OrderDate = c.DateTime(nullable: false,defaultValueSql:"getdate()"),
                    })
                .PrimaryKey(t => t.OrderId)
                .ForeignKey("dbo.tbl_Customers", t => t.CustomerId, cascadeDelete: true)
                .Index(t => t.CustomerId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.tbl_Orders", "CustomerId", "dbo.tbl_Customers");
            DropIndex("dbo.tbl_Orders", new[] { "CustomerId" });
            DropTable("dbo.tbl_Orders");
            DropTable("dbo.tbl_Customers");
        }
    }
}
