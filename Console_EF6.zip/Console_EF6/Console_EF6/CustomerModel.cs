﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace Console_EF6
{
    [Table("tbl_Customers")]
    class CustomerModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CustomerID { get; set; }
        [Required]
        [StringLength(100)]
        [Column("CustomerFullName")]
        public string CustomerName { get; set; }
        [Required]
        [StringLength(100)]
        public string CustomerCity { get; set; }
        [NotMapped]
        public string CustomerDetails { get; set; }

        [Required]
        public  string CustomerEmail { get; set; }

        public List<OrderModel> Orders { get; set; }
        
    }
}
