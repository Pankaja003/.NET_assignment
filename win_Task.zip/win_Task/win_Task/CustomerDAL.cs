﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace win_Task
{
    class CustomerDAL
    {
        public Task<bool> LoginAsync(int id,string password)
        {
            Task<bool> t = Task.Run(() =>
            {
                Thread.Sleep(10000);
                if (id == 1001 && password == "pass@123")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            });
            return t;
        }
    }
}
