﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;//ado.net
using System.Data.SqlClient;//ado.net
using System.Configuration;

namespace win_bank_ado
{
    class BankDAL
    {

        public static int Custid;
        public static int Aid;
        SqlConnection con = new SqlConnection
(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int Addcustomer(CustomerModel model)
        {
            try
            {
                SqlCommand com_addcustomer = new SqlCommand("proc_addcustomer", con);
                com_addcustomer.CommandType = CommandType.StoredProcedure;
                com_addcustomer.Parameters.AddWithValue("@name", model.CustomerName);
                com_addcustomer.Parameters.AddWithValue("@email", model.CustomerEmailid);
                com_addcustomer.Parameters.AddWithValue("@mobile", model.CustomerMobileNo);
                com_addcustomer.Parameters.AddWithValue("@gender", model.CustomerGender);
                com_addcustomer.Parameters.AddWithValue("@pwd", model.CustomerPassword);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addcustomer.Parameters.Add(para_return);
                con.Open();
                com_addcustomer.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;

            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool Login(int id, string password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);
                com_login.CommandType = CommandType.StoredProcedure;
                com_login.Parameters.AddWithValue("@id", id);
                com_login.Parameters.AddWithValue("@pwd", password);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(para_return);
                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;

                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


            }
        }
        public int Addaccount(AccountModel model)
        {
            try
            {
                SqlCommand com_addaccount = new SqlCommand("proc_addAccount", con);
                com_addaccount.CommandType = CommandType.StoredProcedure;
              com_addaccount.Parameters.AddWithValue("@customerid", model.CustomerID);
                com_addaccount.Parameters.AddWithValue("@Accountbal", model.AccountBalance);
                com_addaccount.Parameters.AddWithValue("@accounttype", model.AccountType);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addaccount.Parameters.Add(para_return);
                con.Open();
                com_addaccount.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;

            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<AccountModel> search(int id)
        {
            try
            {

                SqlCommand com_search = new SqlCommand("proc_searchAccount", con);
                com_search.CommandType = CommandType.StoredProcedure;
                com_search.Parameters.AddWithValue("@id", id);
                con.Open();
                SqlDataReader dr = com_search.ExecuteReader();
                List<AccountModel> accountlist = new List<AccountModel>();
                while (dr.Read())
                {
                    AccountModel model = new AccountModel();
                    model.AccountID= dr.GetInt32(0);
                    model.CustomerID = dr.GetInt32(1);
                    model.AccountBalance = dr.GetInt32(2);
                    model.AccountType = dr.GetString(3);
                    model.AccountOpeningDate = dr.GetDateTime(4);

                    accountlist.Add(model);
                }
                con.Close();
                return accountlist;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }
        public int Addtransaction(TransactionModel model)
        {
            try
            {
                SqlCommand com_addtransaction = new SqlCommand("proc_addTransaction", con);
                com_addtransaction.CommandType = CommandType.StoredProcedure;
                com_addtransaction.Parameters.AddWithValue("@accountid", model.AccountID);
                com_addtransaction.Parameters.AddWithValue("@amt", model.Amount);
                com_addtransaction.Parameters.AddWithValue("@type", model.TransType);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addtransaction.Parameters.Add(para_return);
                con.Open();
                com_addtransaction.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;

            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<TransactionModel> searchtrans(int id)
        {
            try
            {
                SqlCommand com_search = new SqlCommand("proc_searchTransaction", con);
                com_search.CommandType = CommandType.StoredProcedure;
                com_search.Parameters.AddWithValue("@id", id);
                con.Open();
                SqlDataReader dr = com_search.ExecuteReader();
                List<TransactionModel> Transactionlist = new List<TransactionModel>();
                while (dr.Read())
                {
                    TransactionModel model = new TransactionModel();
                    model.TransID = dr.GetInt32(0);
                    model.AccountID = dr.GetInt32(1);
                    model.Amount = dr.GetInt32(2);
                    model.TransType = dr.GetString(3);
                    model.TransDate = dr.GetDateTime(4);

                    Transactionlist.Add(model);
                }
                con.Close();
                return Transactionlist;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }
               
        public int Accountbalance(int id)
        {
            SqlCommand com_Accountbalance = new SqlCommand("proc_accountbal",con);
            com_Accountbalance.CommandType = CommandType.StoredProcedure;
            com_Accountbalance.Parameters.AddWithValue("@id", id);
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_Accountbalance.Parameters.Add(para_return);
            con.Open();
            com_Accountbalance.ExecuteNonQuery();
            int bal = Convert.ToInt32(para_return.Value);
            con.Close();
            return bal;

        }
                   
    }
}
 