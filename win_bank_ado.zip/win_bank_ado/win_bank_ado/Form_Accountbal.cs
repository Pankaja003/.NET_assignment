﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_bank_ado
{
    public partial class Form_Accountbal : Form
    {
        public Form_Accountbal()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_Showbal_Click(object sender, EventArgs e)
        {
           /* if(txt_accountid.Text==string.Empty)
            {
                lbl_BalanceStaus.Text = "Enter the Account Id";
            }*/
            //else
            //{
                int id = BankDAL.Aid;
                BankDAL dal = new BankDAL();
                int balance = dal.Accountbalance(id);
                lbl_BalanceStaus.Text = "Balance is :" + balance;
          //  }
        }
    }
}
