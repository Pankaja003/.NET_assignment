﻿namespace win_bank_ado
{
    partial class Form_My_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_MyAccount = new System.Windows.Forms.Label();
            this.btn_SearchAccount = new System.Windows.Forms.Button();
            this.dg_Accounts = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Accounts)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_MyAccount
            // 
            this.lbl_MyAccount.AutoSize = true;
            this.lbl_MyAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MyAccount.ForeColor = System.Drawing.Color.Red;
            this.lbl_MyAccount.Location = new System.Drawing.Point(140, 32);
            this.lbl_MyAccount.Name = "lbl_MyAccount";
            this.lbl_MyAccount.Size = new System.Drawing.Size(160, 24);
            this.lbl_MyAccount.TabIndex = 1;
            this.lbl_MyAccount.Text = "My Account Form";
            // 
            // btn_SearchAccount
            // 
            this.btn_SearchAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SearchAccount.ForeColor = System.Drawing.Color.Lime;
            this.btn_SearchAccount.Location = new System.Drawing.Point(144, 74);
            this.btn_SearchAccount.Name = "btn_SearchAccount";
            this.btn_SearchAccount.Size = new System.Drawing.Size(116, 53);
            this.btn_SearchAccount.TabIndex = 3;
            this.btn_SearchAccount.Text = "Search Account";
            this.btn_SearchAccount.UseVisualStyleBackColor = true;
            this.btn_SearchAccount.Click += new System.EventHandler(this.btn_SearchAccount_Click);
            // 
            // dg_Accounts
            // 
            this.dg_Accounts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Accounts.Location = new System.Drawing.Point(12, 148);
            this.dg_Accounts.Name = "dg_Accounts";
            this.dg_Accounts.Size = new System.Drawing.Size(417, 150);
            this.dg_Accounts.TabIndex = 4;
            this.dg_Accounts.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_Accounts_CellContentClick);
            // 
            // Form_My_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 308);
            this.Controls.Add(this.dg_Accounts);
            this.Controls.Add(this.btn_SearchAccount);
            this.Controls.Add(this.lbl_MyAccount);
            this.Name = "Form_My_Account";
            this.Text = "Form_My_Account";
            this.Load += new System.EventHandler(this.Form_My_Account_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_Accounts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_MyAccount;
        private System.Windows.Forms.Button btn_SearchAccount;
        private System.Windows.Forms.DataGridView dg_Accounts;
    }
}