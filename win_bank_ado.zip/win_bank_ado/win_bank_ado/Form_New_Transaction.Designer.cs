﻿namespace win_bank_ado
{
    partial class Form_New_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_NewTransaction = new System.Windows.Forms.Label();
            this.lbl_AccountID = new System.Windows.Forms.Label();
            this.lbl_Amount = new System.Windows.Forms.Label();
            this.lbl_TransactionType = new System.Windows.Forms.Label();
            this.lbl_Status = new System.Windows.Forms.Label();
            this.txt_Amount = new System.Windows.Forms.TextBox();
            this.txt_TransactionType = new System.Windows.Forms.TextBox();
            this.btn_NewTransaction = new System.Windows.Forms.Button();
            this.ddl_AccountId = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_NewTransaction
            // 
            this.lbl_NewTransaction.AutoSize = true;
            this.lbl_NewTransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NewTransaction.ForeColor = System.Drawing.Color.Red;
            this.lbl_NewTransaction.Location = new System.Drawing.Point(151, 30);
            this.lbl_NewTransaction.Name = "lbl_NewTransaction";
            this.lbl_NewTransaction.Size = new System.Drawing.Size(207, 24);
            this.lbl_NewTransaction.TabIndex = 0;
            this.lbl_NewTransaction.Text = "New Transaction  Form";
            // 
            // lbl_AccountID
            // 
            this.lbl_AccountID.AutoSize = true;
            this.lbl_AccountID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AccountID.ForeColor = System.Drawing.Color.Navy;
            this.lbl_AccountID.Location = new System.Drawing.Point(101, 88);
            this.lbl_AccountID.Name = "lbl_AccountID";
            this.lbl_AccountID.Size = new System.Drawing.Size(90, 20);
            this.lbl_AccountID.TabIndex = 1;
            this.lbl_AccountID.Text = "Account Id:";
            // 
            // lbl_Amount
            // 
            this.lbl_Amount.AutoSize = true;
            this.lbl_Amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Amount.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Amount.Location = new System.Drawing.Point(101, 140);
            this.lbl_Amount.Name = "lbl_Amount";
            this.lbl_Amount.Size = new System.Drawing.Size(69, 20);
            this.lbl_Amount.TabIndex = 2;
            this.lbl_Amount.Text = "Amount:";
            // 
            // lbl_TransactionType
            // 
            this.lbl_TransactionType.AutoSize = true;
            this.lbl_TransactionType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TransactionType.ForeColor = System.Drawing.Color.Navy;
            this.lbl_TransactionType.Location = new System.Drawing.Point(101, 199);
            this.lbl_TransactionType.Name = "lbl_TransactionType";
            this.lbl_TransactionType.Size = new System.Drawing.Size(134, 20);
            this.lbl_TransactionType.TabIndex = 3;
            this.lbl_TransactionType.Text = "Transaction Type:";
            // 
            // lbl_Status
            // 
            this.lbl_Status.AutoSize = true;
            this.lbl_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Status.ForeColor = System.Drawing.Color.Red;
            this.lbl_Status.Location = new System.Drawing.Point(101, 322);
            this.lbl_Status.Name = "lbl_Status";
            this.lbl_Status.Size = new System.Drawing.Size(117, 20);
            this.lbl_Status.TabIndex = 4;
            this.lbl_Status.Text = "Transaction ID:";
            // 
            // txt_Amount
            // 
            this.txt_Amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Amount.ForeColor = System.Drawing.Color.Navy;
            this.txt_Amount.Location = new System.Drawing.Point(293, 140);
            this.txt_Amount.Name = "txt_Amount";
            this.txt_Amount.Size = new System.Drawing.Size(172, 26);
            this.txt_Amount.TabIndex = 6;
            // 
            // txt_TransactionType
            // 
            this.txt_TransactionType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TransactionType.ForeColor = System.Drawing.Color.Navy;
            this.txt_TransactionType.Location = new System.Drawing.Point(293, 196);
            this.txt_TransactionType.Name = "txt_TransactionType";
            this.txt_TransactionType.Size = new System.Drawing.Size(172, 26);
            this.txt_TransactionType.TabIndex = 7;
            // 
            // btn_NewTransaction
            // 
            this.btn_NewTransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewTransaction.ForeColor = System.Drawing.Color.Lime;
            this.btn_NewTransaction.Location = new System.Drawing.Point(199, 256);
            this.btn_NewTransaction.Name = "btn_NewTransaction";
            this.btn_NewTransaction.Size = new System.Drawing.Size(132, 51);
            this.btn_NewTransaction.TabIndex = 8;
            this.btn_NewTransaction.Text = "New Transaction";
            this.btn_NewTransaction.UseVisualStyleBackColor = true;
            this.btn_NewTransaction.Click += new System.EventHandler(this.btn_NewTransaction_Click);
            // 
            // ddl_AccountId
            // 
            this.ddl_AccountId.FormattingEnabled = true;
            this.ddl_AccountId.Location = new System.Drawing.Point(293, 88);
            this.ddl_AccountId.Name = "ddl_AccountId";
            this.ddl_AccountId.Size = new System.Drawing.Size(143, 21);
            this.ddl_AccountId.TabIndex = 9;
            // 
            // Form_New_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 394);
            this.Controls.Add(this.ddl_AccountId);
            this.Controls.Add(this.btn_NewTransaction);
            this.Controls.Add(this.txt_TransactionType);
            this.Controls.Add(this.txt_Amount);
            this.Controls.Add(this.lbl_Status);
            this.Controls.Add(this.lbl_TransactionType);
            this.Controls.Add(this.lbl_Amount);
            this.Controls.Add(this.lbl_AccountID);
            this.Controls.Add(this.lbl_NewTransaction);
            this.Name = "Form_New_Transaction";
            this.Text = "Form_New_Transaction";
            this.Load += new System.EventHandler(this.Form_New_Transaction_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_NewTransaction;
        private System.Windows.Forms.Label lbl_AccountID;
        private System.Windows.Forms.Label lbl_Amount;
        private System.Windows.Forms.Label lbl_TransactionType;
        private System.Windows.Forms.Label lbl_Status;
        private System.Windows.Forms.TextBox txt_Amount;
        private System.Windows.Forms.TextBox txt_TransactionType;
        private System.Windows.Forms.Button btn_NewTransaction;
        private System.Windows.Forms.ComboBox ddl_AccountId;
    }
}