﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace win_bank_ado
{
    [TestFixture]
    class TestCase
    {


        [Test]
        public void TestLogin()
        {
            BankDAL dal = new BankDAL();
            bool status = dal.Login(1, "abc@123");
            Assert.AreEqual(status, true);
        }
        [Test]
        public void TestLogin1()
        {
            BankDAL dal = new BankDAL();
            bool status = dal.Login(100, "abbn");
            Assert.AreEqual(status, false);
        }

        [Test]
        public void TestAddCustomer()
        {
            CustomerModel m = new CustomerModel();
            m.CustomerName = "abc";
            m.CustomerEmailid = "pk@123";
            m.CustomerMobileNo = "66738765";
            m.CustomerGender = "Female";
            m.CustomerPassword = "abc@123";
            BankDAL dal = new BankDAL();
            int id = dal.Addcustomer(m);
            Assert.Greater(id, 0);
        }
        
        [Test]
        public void TestAddAccount()
        {
            AccountModel m = new AccountModel();
            m.CustomerID = 1;
            m.AccountBalance = 500;
            m.AccountType = "savings";
           BankDAL dal = new BankDAL();
            int id = dal.Addaccount(m);
            Assert.Greater(id, 0);

        } 

        [Test]
        [TestCase(1)]
        public void TestSearchAccount(int id)
        {
            BankDAL dal = new BankDAL();
            List<AccountModel> model = dal.search(id);
            Assert.Greater(model.Count, 0);
        }
        [Test]
        public void TestAddTransaction()
        {
            TransactionModel m = new TransactionModel();
            m.AccountID = 1002;
            m.Amount = 500;
            m.TransType = "Credit";
            BankDAL dal = new BankDAL();
            int id = dal.Addtransaction(m);
            Assert.Greater(id, 0);

        }


        [Test]
        [TestCase(1002)]
        public void TestSearchTrans(int id)
        {
            BankDAL dal = new BankDAL();
            List<TransactionModel> model = dal.searchtrans(id);
            Assert.Greater(model.Count, 0);

        }



    }
}
