﻿namespace win_bank_ado
{
    partial class Form_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_NewAccount = new System.Windows.Forms.Button();
            this.btn_SearchAccount = new System.Windows.Forms.Button();
            this.btn_NewTransactoin = new System.Windows.Forms.Button();
            this.btn_SearchTransaction = new System.Windows.Forms.Button();
            this.btn_Accountbal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_NewAccount
            // 
            this.btn_NewAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewAccount.ForeColor = System.Drawing.Color.Red;
            this.btn_NewAccount.Location = new System.Drawing.Point(98, 42);
            this.btn_NewAccount.Name = "btn_NewAccount";
            this.btn_NewAccount.Size = new System.Drawing.Size(110, 53);
            this.btn_NewAccount.TabIndex = 0;
            this.btn_NewAccount.Text = "New Account";
            this.btn_NewAccount.UseVisualStyleBackColor = true;
            this.btn_NewAccount.Click += new System.EventHandler(this.btn_NewAccount_Click);
            // 
            // btn_SearchAccount
            // 
            this.btn_SearchAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SearchAccount.ForeColor = System.Drawing.Color.Red;
            this.btn_SearchAccount.Location = new System.Drawing.Point(289, 42);
            this.btn_SearchAccount.Name = "btn_SearchAccount";
            this.btn_SearchAccount.Size = new System.Drawing.Size(120, 53);
            this.btn_SearchAccount.TabIndex = 1;
            this.btn_SearchAccount.Text = "Search Account";
            this.btn_SearchAccount.UseVisualStyleBackColor = true;
            this.btn_SearchAccount.Click += new System.EventHandler(this.btn_SearchAccount_Click);
            // 
            // btn_NewTransactoin
            // 
            this.btn_NewTransactoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewTransactoin.ForeColor = System.Drawing.Color.Red;
            this.btn_NewTransactoin.Location = new System.Drawing.Point(98, 138);
            this.btn_NewTransactoin.Name = "btn_NewTransactoin";
            this.btn_NewTransactoin.Size = new System.Drawing.Size(110, 59);
            this.btn_NewTransactoin.TabIndex = 2;
            this.btn_NewTransactoin.Text = "New Transaction";
            this.btn_NewTransactoin.UseVisualStyleBackColor = true;
            this.btn_NewTransactoin.Click += new System.EventHandler(this.btn_NewTransactoin_Click);
            // 
            // btn_SearchTransaction
            // 
            this.btn_SearchTransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SearchTransaction.ForeColor = System.Drawing.Color.Red;
            this.btn_SearchTransaction.Location = new System.Drawing.Point(289, 138);
            this.btn_SearchTransaction.Name = "btn_SearchTransaction";
            this.btn_SearchTransaction.Size = new System.Drawing.Size(120, 59);
            this.btn_SearchTransaction.TabIndex = 3;
            this.btn_SearchTransaction.Text = "Search Transaction";
            this.btn_SearchTransaction.UseVisualStyleBackColor = true;
            this.btn_SearchTransaction.Click += new System.EventHandler(this.btn_SearchTransaction_Click);
            // 
            // btn_Accountbal
            // 
            this.btn_Accountbal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Accountbal.ForeColor = System.Drawing.Color.Red;
            this.btn_Accountbal.Location = new System.Drawing.Point(198, 252);
            this.btn_Accountbal.Name = "btn_Accountbal";
            this.btn_Accountbal.Size = new System.Drawing.Size(110, 59);
            this.btn_Accountbal.TabIndex = 4;
            this.btn_Accountbal.Text = "Account Balance";
            this.btn_Accountbal.UseVisualStyleBackColor = true;
            this.btn_Accountbal.Click += new System.EventHandler(this.btn_Accountbal_Click);
            // 
            // Form_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 354);
            this.Controls.Add(this.btn_Accountbal);
            this.Controls.Add(this.btn_SearchTransaction);
            this.Controls.Add(this.btn_NewTransactoin);
            this.Controls.Add(this.btn_SearchAccount);
            this.Controls.Add(this.btn_NewAccount);
            this.Name = "Form_home";
            this.Text = "Form_home";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_NewAccount;
        private System.Windows.Forms.Button btn_SearchAccount;
        private System.Windows.Forms.Button btn_NewTransactoin;
        private System.Windows.Forms.Button btn_SearchTransaction;
        private System.Windows.Forms.Button btn_Accountbal;
    }
}