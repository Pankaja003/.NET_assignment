﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_bank_ado
{
    public partial class Form_My_Account : Form
    {
        public Form_My_Account()
        {
            InitializeComponent();
        }

        private void btn_SearchAccount_Click(object sender, EventArgs e)
        {
            BankDAL dal = new BankDAL();
            int id = BankDAL.Custid;
            List<AccountModel> list = dal.search(id);
            dg_Accounts.DataSource = list;
        }

        private void Form_My_Account_Load(object sender, EventArgs e)
        {

        }

        private void dg_Accounts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
