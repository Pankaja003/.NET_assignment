﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_bank_ado
{
    public partial class Form_New_Transaction : Form
    {
        public Form_New_Transaction()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_NewTransaction_Click(object sender, EventArgs e)
        {
            if (ddl_AccountId.Text == string.Empty)
            {
                lbl_Status.Text = "Enter Account ID";

            }
            else if (txt_Amount.Text == string.Empty)
            {
                lbl_Status.Text = "Enter Amount";
            }

            else if (txt_TransactionType.Text == string.Empty)
            {
                lbl_Status.Text = "Enter Transaction Type";
            }
            else
            {
                TransactionModel model = new TransactionModel();
                model.AccountID = Convert.ToInt32(ddl_AccountId.Text);
                model.Amount = Convert.ToInt32(txt_Amount.Text);
                model.TransType = txt_TransactionType.Text;
                BankDAL dal = new BankDAL();

                int id = dal.Addtransaction(model);
                lbl_Status.Text = "Transaction Added, Id:" + id;
                BankDAL.Aid = model.AccountID;

            }
        }
        private void Form_New_Transaction_Load(object sender, EventArgs e)
        {
            BankDAL obj = new BankDAL();
            List<AccountModel> list = obj.search(BankDAL.Custid);
            foreach (AccountModel a in list)
            {
                ddl_AccountId.Items.Add(a.AccountID);
            }
        }
    }
}
