﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_bank_ado
{
    public partial class Form_My_Transaction : Form
    {
        public Form_My_Transaction()
        {
            InitializeComponent();
        }

        private void btn_SearchTransaction_Click(object sender, EventArgs e)
        {
            BankDAL dal = new BankDAL();
            int id = BankDAL.Aid;
            List<TransactionModel> list = dal.searchtrans(id);
            dg_Transactions.DataSource = list;
        }

        private void Form_My_Transaction_Load(object sender, EventArgs e)
        {

        }
    }
}
