﻿namespace win_bank_ado
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CustomerId = new System.Windows.Forms.Label();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.txt_CustomerID = new System.Windows.Forms.TextBox();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.btn_Login = new System.Windows.Forms.Button();
            this.lbl_Status = new System.Windows.Forms.Label();
            this.lbl_Customername = new System.Windows.Forms.Label();
            this.lbl_CustomerEmailId = new System.Windows.Forms.Label();
            this.lbl_MobileNo = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_CustomerPassword = new System.Windows.Forms.Label();
            this.lbl_CustomrID = new System.Windows.Forms.Label();
            this.btn_NewUser = new System.Windows.Forms.Button();
            this.txt_Customername = new System.Windows.Forms.TextBox();
            this.txt_CustomerEmailid = new System.Windows.Forms.TextBox();
            this.txt_Mobileno = new System.Windows.Forms.TextBox();
            this.txt_CustomerPassword = new System.Windows.Forms.TextBox();
            this.lbl_LoginFrom = new System.Windows.Forms.Label();
            this.rdn_male = new System.Windows.Forms.RadioButton();
            this.rdn_Female = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lbl_CustomerId
            // 
            this.lbl_CustomerId.AutoSize = true;
            this.lbl_CustomerId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerId.Location = new System.Drawing.Point(63, 64);
            this.lbl_CustomerId.Name = "lbl_CustomerId";
            this.lbl_CustomerId.Size = new System.Drawing.Size(100, 20);
            this.lbl_CustomerId.TabIndex = 0;
            this.lbl_CustomerId.Text = "Customer Id:";
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Password.Location = new System.Drawing.Point(63, 129);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(82, 20);
            this.lbl_Password.TabIndex = 1;
            this.lbl_Password.Text = "Password:";
            // 
            // txt_CustomerID
            // 
            this.txt_CustomerID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerID.Location = new System.Drawing.Point(169, 64);
            this.txt_CustomerID.Name = "txt_CustomerID";
            this.txt_CustomerID.Size = new System.Drawing.Size(100, 26);
            this.txt_CustomerID.TabIndex = 2;
            // 
            // txt_Password
            // 
            this.txt_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Password.Location = new System.Drawing.Point(169, 129);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(100, 26);
            this.txt_Password.TabIndex = 3;
            // 
            // btn_Login
            // 
            this.btn_Login.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Login.ForeColor = System.Drawing.Color.Lime;
            this.btn_Login.Location = new System.Drawing.Point(119, 194);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(75, 29);
            this.btn_Login.TabIndex = 4;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // lbl_Status
            // 
            this.lbl_Status.AutoSize = true;
            this.lbl_Status.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Status.ForeColor = System.Drawing.Color.Red;
            this.lbl_Status.Location = new System.Drawing.Point(66, 253);
            this.lbl_Status.Name = "lbl_Status";
            this.lbl_Status.Size = new System.Drawing.Size(103, 20);
            this.lbl_Status.TabIndex = 5;
            this.lbl_Status.Text = "Login Status:";
            // 
            // lbl_Customername
            // 
            this.lbl_Customername.AutoSize = true;
            this.lbl_Customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customername.Location = new System.Drawing.Point(383, 64);
            this.lbl_Customername.Name = "lbl_Customername";
            this.lbl_Customername.Size = new System.Drawing.Size(128, 20);
            this.lbl_Customername.TabIndex = 6;
            this.lbl_Customername.Text = "Customer Name:";
            this.lbl_Customername.Click += new System.EventHandler(this.label4_Click);
            // 
            // lbl_CustomerEmailId
            // 
            this.lbl_CustomerEmailId.AutoSize = true;
            this.lbl_CustomerEmailId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerEmailId.Location = new System.Drawing.Point(383, 104);
            this.lbl_CustomerEmailId.Name = "lbl_CustomerEmailId";
            this.lbl_CustomerEmailId.Size = new System.Drawing.Size(137, 20);
            this.lbl_CustomerEmailId.TabIndex = 7;
            this.lbl_CustomerEmailId.Text = "Customer Emailid:";
            // 
            // lbl_MobileNo
            // 
            this.lbl_MobileNo.AutoSize = true;
            this.lbl_MobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MobileNo.Location = new System.Drawing.Point(383, 147);
            this.lbl_MobileNo.Name = "lbl_MobileNo";
            this.lbl_MobileNo.Size = new System.Drawing.Size(83, 20);
            this.lbl_MobileNo.TabIndex = 8;
            this.lbl_MobileNo.Text = "Mobile No:";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.Location = new System.Drawing.Point(383, 194);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(67, 20);
            this.lbl_Gender.TabIndex = 9;
            this.lbl_Gender.Text = "Gender:";
            this.lbl_Gender.Click += new System.EventHandler(this.label7_Click);
            // 
            // lbl_CustomerPassword
            // 
            this.lbl_CustomerPassword.AutoSize = true;
            this.lbl_CustomerPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerPassword.Location = new System.Drawing.Point(383, 237);
            this.lbl_CustomerPassword.Name = "lbl_CustomerPassword";
            this.lbl_CustomerPassword.Size = new System.Drawing.Size(155, 20);
            this.lbl_CustomerPassword.TabIndex = 10;
            this.lbl_CustomerPassword.Text = "Customer Password:";
            // 
            // lbl_CustomrID
            // 
            this.lbl_CustomrID.AutoSize = true;
            this.lbl_CustomrID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomrID.ForeColor = System.Drawing.Color.Red;
            this.lbl_CustomrID.Location = new System.Drawing.Point(383, 362);
            this.lbl_CustomrID.Name = "lbl_CustomrID";
            this.lbl_CustomrID.Size = new System.Drawing.Size(103, 20);
            this.lbl_CustomrID.TabIndex = 11;
            this.lbl_CustomrID.Text = "Customer ID:";
            this.lbl_CustomrID.Click += new System.EventHandler(this.lbl_CustomrId_Click);
            // 
            // btn_NewUser
            // 
            this.btn_NewUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewUser.ForeColor = System.Drawing.Color.Lime;
            this.btn_NewUser.Location = new System.Drawing.Point(482, 294);
            this.btn_NewUser.Name = "btn_NewUser";
            this.btn_NewUser.Size = new System.Drawing.Size(110, 34);
            this.btn_NewUser.TabIndex = 12;
            this.btn_NewUser.Text = "New User";
            this.btn_NewUser.UseVisualStyleBackColor = true;
            this.btn_NewUser.Click += new System.EventHandler(this.btn_NewUser_Click);
            // 
            // txt_Customername
            // 
            this.txt_Customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Customername.Location = new System.Drawing.Point(542, 64);
            this.txt_Customername.Name = "txt_Customername";
            this.txt_Customername.Size = new System.Drawing.Size(160, 26);
            this.txt_Customername.TabIndex = 13;
            // 
            // txt_CustomerEmailid
            // 
            this.txt_CustomerEmailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerEmailid.Location = new System.Drawing.Point(542, 104);
            this.txt_CustomerEmailid.Name = "txt_CustomerEmailid";
            this.txt_CustomerEmailid.Size = new System.Drawing.Size(160, 26);
            this.txt_CustomerEmailid.TabIndex = 14;
            // 
            // txt_Mobileno
            // 
            this.txt_Mobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Mobileno.Location = new System.Drawing.Point(542, 147);
            this.txt_Mobileno.Name = "txt_Mobileno";
            this.txt_Mobileno.Size = new System.Drawing.Size(160, 26);
            this.txt_Mobileno.TabIndex = 15;
            // 
            // txt_CustomerPassword
            // 
            this.txt_CustomerPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerPassword.Location = new System.Drawing.Point(542, 234);
            this.txt_CustomerPassword.Name = "txt_CustomerPassword";
            this.txt_CustomerPassword.Size = new System.Drawing.Size(160, 26);
            this.txt_CustomerPassword.TabIndex = 17;
            // 
            // lbl_LoginFrom
            // 
            this.lbl_LoginFrom.AutoSize = true;
            this.lbl_LoginFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LoginFrom.ForeColor = System.Drawing.Color.Red;
            this.lbl_LoginFrom.Location = new System.Drawing.Point(290, 20);
            this.lbl_LoginFrom.Name = "lbl_LoginFrom";
            this.lbl_LoginFrom.Size = new System.Drawing.Size(107, 24);
            this.lbl_LoginFrom.TabIndex = 18;
            this.lbl_LoginFrom.Text = "Login Form";
            // 
            // rdn_male
            // 
            this.rdn_male.AutoSize = true;
            this.rdn_male.Location = new System.Drawing.Point(542, 194);
            this.rdn_male.Name = "rdn_male";
            this.rdn_male.Size = new System.Drawing.Size(48, 17);
            this.rdn_male.TabIndex = 19;
            this.rdn_male.TabStop = true;
            this.rdn_male.Text = "Male";
            this.rdn_male.UseVisualStyleBackColor = true;
            // 
            // rdn_Female
            // 
            this.rdn_Female.AutoSize = true;
            this.rdn_Female.Location = new System.Drawing.Point(633, 194);
            this.rdn_Female.Name = "rdn_Female";
            this.rdn_Female.Size = new System.Drawing.Size(59, 17);
            this.rdn_Female.TabIndex = 20;
            this.rdn_Female.TabStop = true;
            this.rdn_Female.Text = "Female";
            this.rdn_Female.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 454);
            this.Controls.Add(this.rdn_Female);
            this.Controls.Add(this.rdn_male);
            this.Controls.Add(this.lbl_LoginFrom);
            this.Controls.Add(this.txt_CustomerPassword);
            this.Controls.Add(this.txt_Mobileno);
            this.Controls.Add(this.txt_CustomerEmailid);
            this.Controls.Add(this.txt_Customername);
            this.Controls.Add(this.btn_NewUser);
            this.Controls.Add(this.lbl_CustomrID);
            this.Controls.Add(this.lbl_CustomerPassword);
            this.Controls.Add(this.lbl_Gender);
            this.Controls.Add(this.lbl_MobileNo);
            this.Controls.Add(this.lbl_CustomerEmailId);
            this.Controls.Add(this.lbl_Customername);
            this.Controls.Add(this.lbl_Status);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.txt_CustomerID);
            this.Controls.Add(this.lbl_Password);
            this.Controls.Add(this.lbl_CustomerId);
            this.ForeColor = System.Drawing.Color.Navy;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CustomerId;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.TextBox txt_CustomerID;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Label lbl_Status;
        private System.Windows.Forms.Label lbl_Customername;
        private System.Windows.Forms.Label lbl_CustomerEmailId;
        private System.Windows.Forms.Label lbl_MobileNo;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_CustomerPassword;
        private System.Windows.Forms.Label lbl_CustomrID;
        private System.Windows.Forms.Button btn_NewUser;
        private System.Windows.Forms.TextBox txt_Customername;
        private System.Windows.Forms.TextBox txt_CustomerEmailid;
        private System.Windows.Forms.TextBox txt_Mobileno;
        private System.Windows.Forms.TextBox txt_CustomerPassword;
        private System.Windows.Forms.Label lbl_LoginFrom;
        private System.Windows.Forms.RadioButton rdn_male;
        private System.Windows.Forms.RadioButton rdn_Female;
    }
}

