﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_bank_ado
{
    public partial class Form_New_Account : Form
    {
        public Form_New_Account()
        {
            InitializeComponent();
        }

        private void btn_NewAccount_Click(object sender, EventArgs e)
        {
           /*if (txt_CustomerID.Text == string.Empty)
            {
                lbl_status.Text = "Enter Customer ID";

            }
            else*/ if (txt_AccountBal.Text == string.Empty)
            {
                lbl_status.Text = "Enter AccountBalance";
            }

            else if (txt_AccountType.Text == string.Empty)
            {
                lbl_status.Text = "Enter Account Type";
            }
            else
            {
                AccountModel model = new AccountModel();
                model.CustomerID = BankDAL.Custid;
                model.AccountBalance = Convert.ToInt32(txt_AccountBal.Text);
                model.AccountType = txt_AccountType.Text;
                BankDAL dal = new BankDAL();
                int id = dal.Addaccount(model);
                lbl_status.Text = "Account Added, Id:" + id;
            }
        }

        private void Form_New_Account_Load(object sender, EventArgs e)
        {
           
            
        }
    }
}
    

