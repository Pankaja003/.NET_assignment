﻿namespace win_bank_ado
{
    partial class Form_My_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_MyTransactionForm = new System.Windows.Forms.Label();
            this.btn_SearchTransaction = new System.Windows.Forms.Button();
            this.dg_Transactions = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Transactions)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_MyTransactionForm
            // 
            this.lbl_MyTransactionForm.AutoSize = true;
            this.lbl_MyTransactionForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MyTransactionForm.ForeColor = System.Drawing.Color.Red;
            this.lbl_MyTransactionForm.Location = new System.Drawing.Point(130, 23);
            this.lbl_MyTransactionForm.Name = "lbl_MyTransactionForm";
            this.lbl_MyTransactionForm.Size = new System.Drawing.Size(188, 24);
            this.lbl_MyTransactionForm.TabIndex = 0;
            this.lbl_MyTransactionForm.Text = "My Transaction Form";
            // 
            // btn_SearchTransaction
            // 
            this.btn_SearchTransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SearchTransaction.ForeColor = System.Drawing.Color.Green;
            this.btn_SearchTransaction.Location = new System.Drawing.Point(150, 60);
            this.btn_SearchTransaction.Name = "btn_SearchTransaction";
            this.btn_SearchTransaction.Size = new System.Drawing.Size(140, 54);
            this.btn_SearchTransaction.TabIndex = 3;
            this.btn_SearchTransaction.Text = "Search Transaction ";
            this.btn_SearchTransaction.UseVisualStyleBackColor = true;
            this.btn_SearchTransaction.Click += new System.EventHandler(this.btn_SearchTransaction_Click);
            // 
            // dg_Transactions
            // 
            this.dg_Transactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Transactions.Location = new System.Drawing.Point(12, 135);
            this.dg_Transactions.Name = "dg_Transactions";
            this.dg_Transactions.Size = new System.Drawing.Size(437, 150);
            this.dg_Transactions.TabIndex = 4;
            // 
            // Form_My_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(461, 297);
            this.Controls.Add(this.dg_Transactions);
            this.Controls.Add(this.btn_SearchTransaction);
            this.Controls.Add(this.lbl_MyTransactionForm);
            this.Name = "Form_My_Transaction";
            this.Text = "Form_My_Transaction";
            this.Load += new System.EventHandler(this.Form_My_Transaction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_Transactions)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_MyTransactionForm;
        private System.Windows.Forms.Button btn_SearchTransaction;
        private System.Windows.Forms.DataGridView dg_Transactions;
    }
}