﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace win_bank_ado
{
    class CustomerModel
    {

        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmailid { get; set; }
        public string CustomerMobileNo { get; set; }
        public string CustomerGender { get; set; }
        public string CustomerPassword { get; set; }
     }
}
