﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_bank_ado
{
    public partial class Form_home : Form
    {
        public Form_home()
        {
            InitializeComponent();
        }

        private void btn_NewAccount_Click(object sender, EventArgs e)
        {
            Form_New_Account obj = new Form_New_Account();
            obj.Show();
        }

        private void btn_SearchAccount_Click(object sender, EventArgs e)
        {
            Form_My_Account obj = new Form_My_Account();
            obj.Show();
        }

        private void btn_NewTransactoin_Click(object sender, EventArgs e)
        {
            Form_New_Transaction obj = new Form_New_Transaction();
            obj.Show();
        }

        private void btn_SearchTransaction_Click(object sender, EventArgs e)
        {
            Form_My_Transaction obj = new Form_My_Transaction();
            obj.Show();
        }

        private void btn_Accountbal_Click(object sender, EventArgs e)
        {
            Form_Accountbal obj = new Form_Accountbal();
            obj.Show();
        }
    }
}
