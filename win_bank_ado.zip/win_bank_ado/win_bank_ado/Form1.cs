﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_bank_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            if (txt_CustomerID.Text == string.Empty)
            {
                lbl_CustomerId.Text = "Enter customer Id";
            }
            else if (txt_Password.Text == string.Empty)
            {
                lbl_Password.Text = "Enter your Password";
            }
            else
            {
                int Customerid = Convert.ToInt32(txt_CustomerID.Text);
                string password = txt_Password.Text;
                BankDAL dal = new BankDAL();
                bool status = dal.Login(Customerid, password);
                if (status == true)
                {
                    BankDAL.Custid = Customerid;
                    Form_home obj = new Form_home();
                    obj.Show();
                }
                else
                {
                    lbl_Status.Text = "Invalid user Id or Password";
                }
            }
        }

        private void btn_NewUser_Click(object sender, EventArgs e)
        {
            if (txt_Customername.Text == string.Empty)
            {
                lbl_CustomrID.Text = "Enter Customer Name";

            }
            else if (txt_CustomerEmailid.Text == string.Empty)
            {
                lbl_CustomrID.Text = "Enter Emailid";
            }

           else if (txt_Mobileno.Text == string.Empty)
            {
                lbl_CustomrID.Text = "Enter Mobileno";
            }
            else if (rdn_male.Text == string.Empty&&rdn_Female.Text==string.Empty)
            {
                lbl_CustomrID.Text = "Enter Gender";
            }
          
            else if (txt_CustomerPassword.Text == string.Empty)
            {
                lbl_CustomrID.Text = "Enter Customer password";
            }
            else
            {
                CustomerModel model = new CustomerModel();
                model.CustomerName = txt_Customername.Text;
               
                model.CustomerEmailid = txt_CustomerEmailid.Text;
                model.CustomerMobileNo = txt_Mobileno.Text;
                if (rdn_male.Checked == true)
                {
                    model.CustomerGender = "Male";
                }
                else 
                {
                    model.CustomerGender = "Female";
                }

                model.CustomerPassword = txt_CustomerPassword.Text;
                BankDAL dal = new BankDAL();
                int id = dal.Addcustomer(model);
                lbl_CustomrID.Text = "Customer Added, Id:" + id;
            }
        }

        private void lbl_CustomrId_Click(object sender, EventArgs e)
        {

        }
    }
}
