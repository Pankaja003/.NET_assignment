﻿namespace win_bank_ado
{
    partial class Form_New_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_NewAccount = new System.Windows.Forms.Button();
            this.lbl_AccountBal = new System.Windows.Forms.Label();
            this.lbl_AccountType = new System.Windows.Forms.Label();
            this.txt_AccountBal = new System.Windows.Forms.TextBox();
            this.txt_AccountType = new System.Windows.Forms.TextBox();
            this.lbl_status = new System.Windows.Forms.Label();
            this.lbl_NewAccountForm = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_NewAccount
            // 
            this.btn_NewAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewAccount.ForeColor = System.Drawing.Color.Lime;
            this.btn_NewAccount.Location = new System.Drawing.Point(233, 270);
            this.btn_NewAccount.Name = "btn_NewAccount";
            this.btn_NewAccount.Size = new System.Drawing.Size(98, 57);
            this.btn_NewAccount.TabIndex = 2;
            this.btn_NewAccount.Text = "New Account";
            this.btn_NewAccount.UseVisualStyleBackColor = true;
            this.btn_NewAccount.Click += new System.EventHandler(this.btn_NewAccount_Click);
            // 
            // lbl_AccountBal
            // 
            this.lbl_AccountBal.AutoSize = true;
            this.lbl_AccountBal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AccountBal.ForeColor = System.Drawing.Color.Navy;
            this.lbl_AccountBal.Location = new System.Drawing.Point(154, 148);
            this.lbl_AccountBal.Name = "lbl_AccountBal";
            this.lbl_AccountBal.Size = new System.Drawing.Size(99, 20);
            this.lbl_AccountBal.TabIndex = 3;
            this.lbl_AccountBal.Text = "Account Bal:";
            // 
            // lbl_AccountType
            // 
            this.lbl_AccountType.AutoSize = true;
            this.lbl_AccountType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AccountType.ForeColor = System.Drawing.Color.Navy;
            this.lbl_AccountType.Location = new System.Drawing.Point(153, 214);
            this.lbl_AccountType.Name = "lbl_AccountType";
            this.lbl_AccountType.Size = new System.Drawing.Size(110, 20);
            this.lbl_AccountType.TabIndex = 4;
            this.lbl_AccountType.Text = "Account Type:";
            // 
            // txt_AccountBal
            // 
            this.txt_AccountBal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AccountBal.ForeColor = System.Drawing.Color.Navy;
            this.txt_AccountBal.Location = new System.Drawing.Point(288, 145);
            this.txt_AccountBal.Name = "txt_AccountBal";
            this.txt_AccountBal.Size = new System.Drawing.Size(100, 26);
            this.txt_AccountBal.TabIndex = 5;
            // 
            // txt_AccountType
            // 
            this.txt_AccountType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AccountType.ForeColor = System.Drawing.Color.Navy;
            this.txt_AccountType.Location = new System.Drawing.Point(288, 208);
            this.txt_AccountType.Name = "txt_AccountType";
            this.txt_AccountType.Size = new System.Drawing.Size(100, 26);
            this.txt_AccountType.TabIndex = 6;
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_status.ForeColor = System.Drawing.Color.Red;
            this.lbl_status.Location = new System.Drawing.Point(153, 362);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(90, 20);
            this.lbl_status.TabIndex = 7;
            this.lbl_status.Text = "Account Id:";
            // 
            // lbl_NewAccountForm
            // 
            this.lbl_NewAccountForm.AutoSize = true;
            this.lbl_NewAccountForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NewAccountForm.ForeColor = System.Drawing.Color.Red;
            this.lbl_NewAccountForm.Location = new System.Drawing.Point(154, 19);
            this.lbl_NewAccountForm.Name = "lbl_NewAccountForm";
            this.lbl_NewAccountForm.Size = new System.Drawing.Size(179, 24);
            this.lbl_NewAccountForm.TabIndex = 8;
            this.lbl_NewAccountForm.Text = "New Account  Form";
            // 
            // Form_New_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 438);
            this.Controls.Add(this.lbl_NewAccountForm);
            this.Controls.Add(this.lbl_status);
            this.Controls.Add(this.txt_AccountType);
            this.Controls.Add(this.txt_AccountBal);
            this.Controls.Add(this.lbl_AccountType);
            this.Controls.Add(this.lbl_AccountBal);
            this.Controls.Add(this.btn_NewAccount);
            this.Name = "Form_New_Account";
            this.Text = "Form_New_Account";
            this.Load += new System.EventHandler(this.Form_New_Account_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_NewAccount;
        private System.Windows.Forms.Label lbl_AccountBal;
        private System.Windows.Forms.Label lbl_AccountType;
        private System.Windows.Forms.TextBox txt_AccountBal;
        private System.Windows.Forms.TextBox txt_AccountType;
        private System.Windows.Forms.Label lbl_status;
        private System.Windows.Forms.Label lbl_NewAccountForm;
    }
}