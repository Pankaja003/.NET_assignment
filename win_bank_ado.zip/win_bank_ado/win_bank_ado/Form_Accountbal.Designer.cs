﻿namespace win_bank_ado
{
    partial class Form_Accountbal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Showbal = new System.Windows.Forms.Button();
            this.lbl_BalanceStaus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Showbal
            // 
            this.btn_Showbal.Location = new System.Drawing.Point(364, 66);
            this.btn_Showbal.Name = "btn_Showbal";
            this.btn_Showbal.Size = new System.Drawing.Size(75, 23);
            this.btn_Showbal.TabIndex = 0;
            this.btn_Showbal.Text = "showBal";
            this.btn_Showbal.UseVisualStyleBackColor = true;
            this.btn_Showbal.Click += new System.EventHandler(this.btn_Showbal_Click);
            // 
            // lbl_BalanceStaus
            // 
            this.lbl_BalanceStaus.AutoSize = true;
            this.lbl_BalanceStaus.Location = new System.Drawing.Point(49, 78);
            this.lbl_BalanceStaus.Name = "lbl_BalanceStaus";
            this.lbl_BalanceStaus.Size = new System.Drawing.Size(82, 13);
            this.lbl_BalanceStaus.TabIndex = 1;
            this.lbl_BalanceStaus.Text = "Balance Status ";
            this.lbl_BalanceStaus.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form_Accountbal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 261);
            this.Controls.Add(this.lbl_BalanceStaus);
            this.Controls.Add(this.btn_Showbal);
            this.Name = "Form_Accountbal";
            this.Text = "Form_Accountbal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Showbal;
        private System.Windows.Forms.Label lbl_BalanceStaus;
    }
}