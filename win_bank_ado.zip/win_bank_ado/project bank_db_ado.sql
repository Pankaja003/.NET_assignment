create database db_bank_ado

create table tbl_Customers 
(
CustomerID int identity(1,1) primary key,
CustomerName varchar(100) not null, 
CustomerEmail varchar(100) not null ,
 CustomerMobile  varchar(100) not null, 
 CustomerGender varchar(100) not null check(CustomerGender in('male','Female')),
 CustomerPassword varchar(100) not null
 )



 alter proc proc_addcustomer(@name varchar(100),@email varchar(100),@mobile varchar(100),@gender varchar(100),@pwd varchar(100))
 as
 begin
 insert tbl_Customers values(@name ,@email ,@mobile ,@gender ,@pwd )
 return @@identity
 end

 create proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int=0
select @count=count(*) from tbl_customers
where customerid=@id and Customerpassword=@pwd
return @count
end

create table tbl_Accounts 
(
AccountID int identity(1001,1) primary key,
CustomerID int  not null foreign key references tbl_Customers(CustomerID),
AccountBal int not null check(Accountbal>0),
AccountType varchar(100) not null check(AccountType in('Savings','Current')),
AccountOpeningDate datetime not null
)

create proc proc_addAccount(@customerid int,@Accountbal int,@accounttype varchar(100))
as
begin
insert tbl_Accounts values(@customerid ,@Accountbal ,@accounttype,getdate())
return @@identity
end
select * from tbl_Accounts

create proc proc_searchAccount(@id int)
as
begin
select * from tbl_Accounts where CustomerID=@id  
end

create table tbl_Transactions
(
TransID int identity(101,1) primary key,
AccountID int not null foreign key references tbl_Accounts(AccountID),
 Amount  int not null check(Amount>0),
 TransType varchar(100) not null check(TransType in('Credit','Debit')),
 TransDate datetime not null
 )


create proc proc_addTransaction(@accountid int,@amt int,@type varchar(100))
as
begin
insert tbl_Transactions values(@accountid ,@amt,@type,getdate())
return @@identity
end

alter proc proc_searchTransaction(@id int)
as
begin
select top 5  * from tbl_Transactions
where accountid=@id
order by TransDate desc 
end

alter trigger trg_accountBal
on  tbl_Transactions
for  insert
as
begin
declare @accountid int
declare @amount int
declare @transactiontype varchar(100)
declare @Accountbal int
select @accountid=AccountID, @amount=Amount,@transactiontype=TransType from inserted
select @Accountbal=accountbal from tbl_Accounts where AccountID=@accountid
if(@transactiontype='Debit'and @amount<@Accountbal)
begin
update tbl_Accounts set Accountbal=accountbal-@amount where accountid=@accountid
end
if(@transactiontype='Credit')
begin
update tbl_Accounts set Accountbal=accountbal+@amount where accountid=@accountid
end
end




select * from tbl_customers

select * from tbl_Accounts

select * from tbl_Transactions


create proc proc_accountbal(@id int)
as
declare @bal int
select @bal=Accountbal from tbl_Accounts where AccountID=@id
return @bal


