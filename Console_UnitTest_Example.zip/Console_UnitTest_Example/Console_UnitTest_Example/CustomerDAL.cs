﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_UnitTest_Example
{
    class CustomerDAL
    {

        public bool Login(int id, string password)
        {
            if(id ==1000 && password=="pass@123")

                 { 
                    return true;
                 }
             else
                {
                    return false;
                }
            }
       public int AddCustomer(CustomerModel model)
        {
            //ado.Net
            return 1000;
        }
        public CustomerModel Find(int id)
        {
            //ado.net
            return new CustomerModel();
        }

        public List<CustomerModel> Search(string key)
        {
            //ado.net
            List<CustomerModel> list = new List<CustomerModel>();
            CustomerModel m = new CustomerModel();
            m.CustomerId = 1;
            m.CustomerName = "abc";
            m.Customercity = "bgl";
            m.CustomerPassword = "pass";
                list.Add(m);
            return list;
        }

        public int GetAccountBalance(int AccountID)
        {
            return 2000;
        }

        

            

        
    }
}
