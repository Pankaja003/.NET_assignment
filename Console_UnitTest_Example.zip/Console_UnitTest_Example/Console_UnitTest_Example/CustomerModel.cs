﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_UnitTest_Example
{
    class CustomerModel
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Customercity { get; set; }

        public string CustomerPassword { get; set; }

    }
}
