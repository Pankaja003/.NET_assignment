﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Console_UnitTest_Example
{
    [TestFixture]//attribute or metadata
    class MyNUnitTestCases
    {
        [Test]
        public void TestLogin()
        {
            CustomerDAL dal = new CustomerDAL();
            bool status = dal.Login(1000, "pass@123");
            Assert.AreEqual(status, true);
        }
        [Test]
        public void TestAddCustomer()
        {
            CustomerModel m = new CustomerModel();
            m.CustomerName = "ABC";
            m.CustomerPassword = "pass@123";
            m.Customercity = "BGL";
            CustomerDAL dal = new CustomerDAL();
            int id = dal.AddCustomer(m);
            Assert.Greater(id, 0);
        }
        [Test]
        [TestCase(1000)]

        public void TestFind(int id)
        {
            CustomerDAL dal = new CustomerDAL();
            CustomerModel m = dal.Find(id);
            Assert.NotNull(m);
        }

        [Test]
        [TestCase("XYZ")]
        public void TestSearch(string key)
        {
            CustomerDAL dal = new CustomerDAL();
            List<CustomerModel> model = dal.Search(key);
            Assert.Greater(model.Count, 0);

        }
        [Test]
        public void  TestAccountBalance()
        {
            CustomerDAL dal = new CustomerDAL();
            int balance = dal.GetAccountBalance(1000);
            Assert.AreEqual(balance, 2000);
        }

    }
}
