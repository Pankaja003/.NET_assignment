﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Auto_GC_Program
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 20, 30, 40, 50, 60 };
            Test3 obj = new Test3();
            obj.Call(10,12,24,56,90);

           /* int i = 0;
            Test2 obj1 = null;
            while(i<5)
            {
                 obj1 = new Test2();
               //obj1 = null;
               // GC.SuppressFinalize(obj1);
                i++;
            }
            GC.Collect();//for destroying null objects*/

            Console.ReadLine();

        }
    }
}
