﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Auto_GC_Program
{
    class Test2
    {
        public int ID { get; }
        public string Name { get; set; }
        private static int Count = 1000;
        public Test2()
        {
            Console.WriteLine("Constructor is Called..");
            this.ID = ++Test2.Count;
        }
        ~Test2()
        {
            Console.WriteLine("Destructor  is Called");//Finalize function

        }
            
    }
}
