﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Auto_GC_Program
{
    class Test
    {
        public int StudentId { get; } = 1;//_studentId=1,Readonly
        public string StudentName { get; set; }//_StudentName
        private static int Count = 1000;
        public Test(String StudentName)
        {
            this.StudentId = StudentId;
            this.StudentName = StudentName;
        }
    }
}
