﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hassignment5
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] arr = new int[5];

           

            Console.WriteLine("Enter the elements of array:");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("Element-{0}:", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("array elements are:");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
            int big = arr[0];

          
            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] > big)
                {
                    big = arr[i];
                }
            }
            Console.WriteLine("Bigestest Element:" + big);
               Console.ReadLine();
        }
    }
}
