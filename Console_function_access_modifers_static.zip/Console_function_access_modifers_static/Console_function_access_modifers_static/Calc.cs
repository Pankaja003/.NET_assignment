﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_function_access_modifers_static
{
    class Calc
    {

        public int AddNumbers(int n1,int n2)
        {
            return n1 + n2;
        }
        public int AddNumbers(int n1,int n2,int n3)
        {
            return n1+n2+n3;
        }
        public double AddNumbers(double d1,double d2)
        {
            return d1 + d2;
        }
        public double AddNumbers(int n1,double d1)
        {
            return d1 + n1;
        }
        public double AddNumbers(double d1,int n1)
        {
            return d1 + n1;
        }
    }
}
