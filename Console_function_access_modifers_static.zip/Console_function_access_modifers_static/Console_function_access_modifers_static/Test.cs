﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_function_access_modifers_static
{
    class Test
    {
        public void Call1(int a)
        {
            a = 200;
        }
        public void Call2(ref int a)
        {
            a = a + 10;
        }
            
        public void Call3(out int a)
        {
            //a=a+10;error
            a = 200;
        }
    }
}
