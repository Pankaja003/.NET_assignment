﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_function_access_modifers_static
{
    partial  class XYZ
    {
      public void Call3()
        {

        }
        public void Call4()
        { }
    }
}
