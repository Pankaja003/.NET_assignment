﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_function_access_modifers_static
{
    class Test_Static

    {
        static Test_Static()
        {
            Console.WriteLine("This is Static Constructor");
            Test_Static.count = 10;
        }
        public Test_Static()
        {
            Test_Static.count = 10;
        }
        public static int count;//defalut 0
        public static void Call()
        {
            Console.WriteLine("It is static Function");
        } 

    }
}
