﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_function_access_modifers_static
{
    class Program
    {
        static void Main(string[] args)
        {
            /* int n1 = 100;
             int n2 = 200;
             int n3 = 300;
             double d1 = 10.2;
             double d2 = 30.4;

             Calc obj = new Calc();
             int r1 = obj.AddNumbers(n1, n2);
             int r2 = obj.AddNumbers(n1, n2, n3);
             double r3 = obj.AddNumbers(d1, d2);
             double r4 = obj.AddNumbers(n1, d1);
             double r5 = obj.AddNumbers(d1, n1);
             Console.WriteLine(r1);
             Console.WriteLine(r2);
             Console.WriteLine(r3);
             Console.WriteLine(r4);
             Console.WriteLine(r5);*/

            Test obj = new Test();
            int i; //= 100;
           // obj.Call1(i);//call by value
           // obj.Call2(ref i);//call by ref
           obj.Call3(out i);
            Console.WriteLine(i);


           /* Test_Static.count =Test_Static.count+ 10;//20
         

            Console.WriteLine(Test_Static.count);//20
            Test_Static.count = 30;//30
            Test_Static obj = new Test_Static();//10
            Console.WriteLine(Test_Static.count);
            Test_Static.Call(); */
                

            Console.ReadLine();
        }
    }
}
