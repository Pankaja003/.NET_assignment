﻿namespace Win_IO_Serialization
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_createandBinaryFile = new System.Windows.Forms.Button();
            this.btn_readingbinary = new System.Windows.Forms.Button();
            this.btn_Writestream = new System.Windows.Forms.Button();
            this.btn_readStream = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_createandBinaryFile
            // 
            this.btn_createandBinaryFile.Location = new System.Drawing.Point(208, 53);
            this.btn_createandBinaryFile.Name = "btn_createandBinaryFile";
            this.btn_createandBinaryFile.Size = new System.Drawing.Size(179, 23);
            this.btn_createandBinaryFile.TabIndex = 0;
            this.btn_createandBinaryFile.Text = "Create Write binary ";
            this.btn_createandBinaryFile.UseVisualStyleBackColor = true;
            this.btn_createandBinaryFile.Click += new System.EventHandler(this.btn_createandBinaryFile_Click);
            // 
            // btn_readingbinary
            // 
            this.btn_readingbinary.Location = new System.Drawing.Point(208, 120);
            this.btn_readingbinary.Name = "btn_readingbinary";
            this.btn_readingbinary.Size = new System.Drawing.Size(179, 23);
            this.btn_readingbinary.TabIndex = 1;
            this.btn_readingbinary.Text = "read binary";
            this.btn_readingbinary.UseVisualStyleBackColor = true;
            this.btn_readingbinary.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_Writestream
            // 
            this.btn_Writestream.Location = new System.Drawing.Point(208, 187);
            this.btn_Writestream.Name = "btn_Writestream";
            this.btn_Writestream.Size = new System.Drawing.Size(179, 23);
            this.btn_Writestream.TabIndex = 2;
            this.btn_Writestream.Text = "Write stream";
            this.btn_Writestream.UseVisualStyleBackColor = true;
            this.btn_Writestream.Click += new System.EventHandler(this.btn_Writestream_Click);
            // 
            // btn_readStream
            // 
            this.btn_readStream.Location = new System.Drawing.Point(185, 251);
            this.btn_readStream.Name = "btn_readStream";
            this.btn_readStream.Size = new System.Drawing.Size(179, 23);
            this.btn_readStream.TabIndex = 3;
            this.btn_readStream.Text = "Read stream";
            this.btn_readStream.UseVisualStyleBackColor = true;
            this.btn_readStream.Click += new System.EventHandler(this.btn_readStream_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 367);
            this.Controls.Add(this.btn_readStream);
            this.Controls.Add(this.btn_Writestream);
            this.Controls.Add(this.btn_readingbinary);
            this.Controls.Add(this.btn_createandBinaryFile);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_createandBinaryFile;
        private System.Windows.Forms.Button btn_readingbinary;
        private System.Windows.Forms.Button btn_Writestream;
        private System.Windows.Forms.Button btn_readStream;
    }
}

