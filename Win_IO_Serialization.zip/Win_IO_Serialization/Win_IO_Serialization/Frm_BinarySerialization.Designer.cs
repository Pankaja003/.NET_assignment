﻿namespace Win_IO_Serialization
{
    partial class Frm_BinarySerialization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_BinarySerializtaion = new System.Windows.Forms.Button();
            this.btn_BinaryDeserialization = new System.Windows.Forms.Button();
            this.btn_XML_Serialization = new System.Windows.Forms.Button();
            this.btn_XML_De_serialization = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_BinarySerializtaion
            // 
            this.btn_BinarySerializtaion.Location = new System.Drawing.Point(105, 28);
            this.btn_BinarySerializtaion.Name = "btn_BinarySerializtaion";
            this.btn_BinarySerializtaion.Size = new System.Drawing.Size(250, 23);
            this.btn_BinarySerializtaion.TabIndex = 0;
            this.btn_BinarySerializtaion.Text = "Binary Serialization";
            this.btn_BinarySerializtaion.UseVisualStyleBackColor = true;
            this.btn_BinarySerializtaion.Click += new System.EventHandler(this.btn_BinarySerializtaion_Click);
            // 
            // btn_BinaryDeserialization
            // 
            this.btn_BinaryDeserialization.Location = new System.Drawing.Point(102, 95);
            this.btn_BinaryDeserialization.Name = "btn_BinaryDeserialization";
            this.btn_BinaryDeserialization.Size = new System.Drawing.Size(250, 57);
            this.btn_BinaryDeserialization.TabIndex = 1;
            this.btn_BinaryDeserialization.Text = "Binary De serialization";
            this.btn_BinaryDeserialization.UseVisualStyleBackColor = true;
            this.btn_BinaryDeserialization.Click += new System.EventHandler(this.btn_BinaryDeserialization_Click);
            // 
            // btn_XML_Serialization
            // 
            this.btn_XML_Serialization.Location = new System.Drawing.Point(102, 178);
            this.btn_XML_Serialization.Name = "btn_XML_Serialization";
            this.btn_XML_Serialization.Size = new System.Drawing.Size(250, 57);
            this.btn_XML_Serialization.TabIndex = 2;
            this.btn_XML_Serialization.Text = "XML  serialization";
            this.btn_XML_Serialization.UseVisualStyleBackColor = true;
            this.btn_XML_Serialization.Click += new System.EventHandler(this.btn_XML_Serialization_Click);
            // 
            // btn_XML_De_serialization
            // 
            this.btn_XML_De_serialization.Location = new System.Drawing.Point(102, 265);
            this.btn_XML_De_serialization.Name = "btn_XML_De_serialization";
            this.btn_XML_De_serialization.Size = new System.Drawing.Size(250, 57);
            this.btn_XML_De_serialization.TabIndex = 3;
            this.btn_XML_De_serialization.Text = "XML De serialization";
            this.btn_XML_De_serialization.UseVisualStyleBackColor = true;
            this.btn_XML_De_serialization.Click += new System.EventHandler(this.btn_XML_De_serialization_Click);
            // 
            // Frm_BinarySerialization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 363);
            this.Controls.Add(this.btn_XML_De_serialization);
            this.Controls.Add(this.btn_XML_Serialization);
            this.Controls.Add(this.btn_BinaryDeserialization);
            this.Controls.Add(this.btn_BinarySerializtaion);
            this.Name = "Frm_BinarySerialization";
            this.Text = "Frm_BinarySerialization";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_BinarySerializtaion;
        private System.Windows.Forms.Button btn_BinaryDeserialization;
        private System.Windows.Forms.Button btn_XML_Serialization;
        private System.Windows.Forms.Button btn_XML_De_serialization;
    }
}