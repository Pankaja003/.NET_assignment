﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Win_IO_Serialization
{
    public partial class Frm_BinarySerialization : Form
    {
        public Frm_BinarySerialization()
        {
            InitializeComponent();
        }

        private void btn_BinarySerializtaion_Click(object sender, EventArgs e)
        {
            Product obj = new Product();
            obj.ProductID = 1001;
            obj.ProductName = "Mobile Phone";
            obj.ProductPrice = 20000;
            FileStream fs = new FileStream
                ("C:/test/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(fs, obj);
            fs.Close();
            MessageBox.Show("Object Serialized Successfully");
        }

        private void btn_BinaryDeserialization_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream
                            ("C:/test/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            Product p = b.Deserialize(fs) as Product;
            fs.Close();
            MessageBox.Show(p.ProductID + "" + p.ProductName + "" + p.ProductPrice);

        }

        private void btn_XML_Serialization_Click(object sender, EventArgs e)
        {
            Product p = new Product();
            p.ProductID = 1000;
            p.ProductName = "Laptop";
            p.ProductPrice = 20000;
            FileStream fs = new FileStream
                      ("C:/test/product.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            xml.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("Object Serialized in XML Format");
        }

        private void btn_XML_De_serialization_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream
                ("C:/test/product.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            Product p = xml.Deserialize(fs) as Product;
            fs.Close();
            MessageBox.Show(p.ProductID + "" + p.ProductName + "" + p.ProductPrice);

        }
    }
}
