﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Win_IO_Serialization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_createandBinaryFile_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream
                ("C:/test/abc.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            int i = 100;
            bw.Write(i);
            bw.Flush();
            fs.Close();
            MessageBox.Show("File Created");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream
                ("c:/test/abc.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryReader br = new BinaryReader(fs);
            int i = br.ReadInt32();
            fs.Close();
            MessageBox.Show(i.ToString());


        }

        private void btn_Writestream_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream
                ("c:/test/xyz.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);

            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine("hello dotnet");
            sw.Flush();
            fs.Close();
            MessageBox.Show("File created");


        }

        private void btn_readStream_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream
                ("c:/test/xyz.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs);
            string str = sr.ReadToEnd();
            fs.Close();
            MessageBox.Show(str);
      
        }
    }
}
