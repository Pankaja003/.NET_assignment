﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number 1:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number 2:");
            int num2 = Convert.ToInt32(Console.ReadLine());

            bool flag = true;
            while (flag)
            {
                Console.WriteLine("1-Add,2-sub,3-multiply,4-divide,5-exit,6-reset");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        {
                            int total = num1 + num2;
                            Console.WriteLine("Result :" + total.ToString());
                            break;
                        }
                    case 2:
                        {
                            int total = num1 - num2;
                            Console.WriteLine("Result :" + total.ToString());
                            break;
                        }
                    case 3:
                        {
                            int total = num1 * num2;
                            Console.WriteLine("Result :" + total.ToString());
                            break;
                        }
                    case 4:
                        {
                            int total = num1 / num2;
                            Console.WriteLine("Result :" + total.ToString());
                            break;
                        }
                    case 5:
                        {
                            flag = false;
                            break;
                        }
                    case 6:
                        {
                            Console.WriteLine("Enter number 1:");
                            num1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter number 2:");
                            num2 = Convert.ToInt32(Console.ReadLine());
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid option");
                            break;
                        }
                }
                }

        }
    }
}
