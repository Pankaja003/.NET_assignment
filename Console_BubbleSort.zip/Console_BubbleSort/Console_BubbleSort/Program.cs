﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_BubbleSort
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 40, 20, 10, 33, 18 };

            

            for (int c = 0; c < arr.Length; c++)
            {
                Console.WriteLine(arr[c]);
            }



             for (int c = 0; c < arr.Length; c++)

              {
                  for (int j = c+1; j < arr.Length; j++)

                  {
                      if (arr[j] < arr[c])
                      {
                          int temp = arr[j];
                          arr[j] = arr[c];
                          arr[c] = temp;
                      }

                  }
                  }

              Console.WriteLine("Bubble sort is:");
              for (int c = 0; c < arr.Length; c++)
              {
                  Console.WriteLine(arr[c]);
              }
              
            Console.ReadLine();
        }
    }
}
