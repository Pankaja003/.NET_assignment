﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Sec_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ddl_quantities.Items.Add(1);

            ddl_quantities.Items.Add(2);

            ddl_quantities.Items.Add(3);

            ddl_quantities.Items.Add(4);

            ddl_quantities.Items.Add(5);

            ddl_cities.Items.Add("pune");

            ddl_cities.Items.Add("Chenni");

            ddl_cities.Items.Add("Mumbai");

            ddl_cities.Items.Add("Kolkatta");

            ddl_cities.Items.Add("Uttar pradesh");
        }

        private void rdn_COD_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void btn_PlaceOrder_Click(object sender, EventArgs e)
        {
            if (txt_CustomerName.Text == string.Empty)
            {
                MessageBox.Show("Enter your name");
            }
            else if (txt_ItemName.Text == String.Empty)
            {
                MessageBox.Show("Enter your Item name");
            }
            else if (txt_ItemPrice.Text == string.Empty)
            {
                MessageBox.Show("Enter Item Price");

            }
            else if (ddl_quantities.Text==string.Empty)
            {
                MessageBox.Show("Enter Item Quantity");
            }
            else if(ddl_cities.Text==string.Empty)
                {
                MessageBox.Show("Enter  City");
            }
            else if(rdb_COD.Checked==false&&rdb_NetBank.Checked==false &&rdb_DebitCard.Checked==false)
            {
                MessageBox.Show("Select Payment option");
            }
            else
            {
                string Custname = txt_CustomerName.Text;
                string Itemname = txt_ItemName.Text;
                int Itemprice = Convert.ToInt32(txt_ItemPrice.Text);
                int Itemqty = Convert.ToInt32(ddl_quantities.Text);
                string city = ddl_cities.Text;
                string payment = string.Empty;
                if(rdb_COD.Checked==true)
                {
                    payment = "COD";
                }
                else if(rdb_NetBank.Checked==true)
                {
                    payment = "Net Bank";
                }
                else
                {
                    payment = "Debit Card";
                }

                Order obj = new Win_Sec_Application.Order(Custname, Itemname, Itemprice, Itemqty, city,payment);
                 int id=obj.POrderId;
                MessageBox.Show("Order Id : " +id);
                int amt = obj.getordervalue();
                MessageBox.Show("Order value is:"+amt);

            }

        }

        private void ddl_quantities_SelectedIndexChanged(object sender, EventArgs e)
        {
         

        }

        private void ddl_cities_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void lbl_PaymentOption_Click(object sender, EventArgs e)
        {

        }
    }
}
