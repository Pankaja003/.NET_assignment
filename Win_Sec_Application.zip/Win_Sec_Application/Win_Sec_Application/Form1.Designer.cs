﻿namespace Win_Sec_Application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CustomerName = new System.Windows.Forms.Label();
            this.lbl_ItemName = new System.Windows.Forms.Label();
            this.lbl_ItemPrice = new System.Windows.Forms.Label();
            this.lbl_ItemQty = new System.Windows.Forms.Label();
            this.lbl_OrderCity = new System.Windows.Forms.Label();
            this.lbl_PaymentOption = new System.Windows.Forms.Label();
            this.txt_CustomerName = new System.Windows.Forms.TextBox();
            this.txt_ItemName = new System.Windows.Forms.TextBox();
            this.txt_ItemPrice = new System.Windows.Forms.TextBox();
            this.ddl_quantities = new System.Windows.Forms.ComboBox();
            this.ddl_cities = new System.Windows.Forms.ComboBox();
            this.rdb_COD = new System.Windows.Forms.RadioButton();
            this.rdb_NetBank = new System.Windows.Forms.RadioButton();
            this.rdb_DebitCard = new System.Windows.Forms.RadioButton();
            this.btn_PlaceOrder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_CustomerName
            // 
            this.lbl_CustomerName.AutoSize = true;
            this.lbl_CustomerName.Location = new System.Drawing.Point(62, 47);
            this.lbl_CustomerName.Name = "lbl_CustomerName";
            this.lbl_CustomerName.Size = new System.Drawing.Size(82, 13);
            this.lbl_CustomerName.TabIndex = 0;
            this.lbl_CustomerName.Text = "Customer Name";
            // 
            // lbl_ItemName
            // 
            this.lbl_ItemName.AutoSize = true;
            this.lbl_ItemName.Location = new System.Drawing.Point(65, 92);
            this.lbl_ItemName.Name = "lbl_ItemName";
            this.lbl_ItemName.Size = new System.Drawing.Size(58, 13);
            this.lbl_ItemName.TabIndex = 1;
            this.lbl_ItemName.Text = "Item Name";
            // 
            // lbl_ItemPrice
            // 
            this.lbl_ItemPrice.AutoSize = true;
            this.lbl_ItemPrice.Location = new System.Drawing.Point(69, 129);
            this.lbl_ItemPrice.Name = "lbl_ItemPrice";
            this.lbl_ItemPrice.Size = new System.Drawing.Size(54, 13);
            this.lbl_ItemPrice.TabIndex = 2;
            this.lbl_ItemPrice.Text = "Item Price";
            // 
            // lbl_ItemQty
            // 
            this.lbl_ItemQty.AutoSize = true;
            this.lbl_ItemQty.Location = new System.Drawing.Point(69, 181);
            this.lbl_ItemQty.Name = "lbl_ItemQty";
            this.lbl_ItemQty.Size = new System.Drawing.Size(46, 13);
            this.lbl_ItemQty.TabIndex = 3;
            this.lbl_ItemQty.Text = "Item Qty";
            // 
            // lbl_OrderCity
            // 
            this.lbl_OrderCity.AutoSize = true;
            this.lbl_OrderCity.Location = new System.Drawing.Point(69, 220);
            this.lbl_OrderCity.Name = "lbl_OrderCity";
            this.lbl_OrderCity.Size = new System.Drawing.Size(53, 13);
            this.lbl_OrderCity.TabIndex = 4;
            this.lbl_OrderCity.Text = "Order City";
            // 
            // lbl_PaymentOption
            // 
            this.lbl_PaymentOption.AutoSize = true;
            this.lbl_PaymentOption.Location = new System.Drawing.Point(69, 266);
            this.lbl_PaymentOption.Name = "lbl_PaymentOption";
            this.lbl_PaymentOption.Size = new System.Drawing.Size(82, 13);
            this.lbl_PaymentOption.TabIndex = 5;
            this.lbl_PaymentOption.Text = "Payment Option";
            this.lbl_PaymentOption.Click += new System.EventHandler(this.lbl_PaymentOption_Click);
            // 
            // txt_CustomerName
            // 
            this.txt_CustomerName.Location = new System.Drawing.Point(186, 44);
            this.txt_CustomerName.Name = "txt_CustomerName";
            this.txt_CustomerName.Size = new System.Drawing.Size(172, 20);
            this.txt_CustomerName.TabIndex = 7;
            // 
            // txt_ItemName
            // 
            this.txt_ItemName.Location = new System.Drawing.Point(186, 92);
            this.txt_ItemName.Name = "txt_ItemName";
            this.txt_ItemName.Size = new System.Drawing.Size(172, 20);
            this.txt_ItemName.TabIndex = 8;
            // 
            // txt_ItemPrice
            // 
            this.txt_ItemPrice.Location = new System.Drawing.Point(186, 129);
            this.txt_ItemPrice.Name = "txt_ItemPrice";
            this.txt_ItemPrice.Size = new System.Drawing.Size(172, 20);
            this.txt_ItemPrice.TabIndex = 9;
            // 
            // ddl_quantities
            // 
            this.ddl_quantities.FormattingEnabled = true;
            this.ddl_quantities.Location = new System.Drawing.Point(178, 178);
            this.ddl_quantities.Name = "ddl_quantities";
            this.ddl_quantities.Size = new System.Drawing.Size(180, 21);
            this.ddl_quantities.TabIndex = 10;
            this.ddl_quantities.SelectedIndexChanged += new System.EventHandler(this.ddl_quantities_SelectedIndexChanged);
            // 
            // ddl_cities
            // 
            this.ddl_cities.FormattingEnabled = true;
            this.ddl_cities.Location = new System.Drawing.Point(178, 220);
            this.ddl_cities.Name = "ddl_cities";
            this.ddl_cities.Size = new System.Drawing.Size(172, 21);
            this.ddl_cities.TabIndex = 11;
            this.ddl_cities.SelectedIndexChanged += new System.EventHandler(this.ddl_cities_SelectedIndexChanged);
            // 
            // rdb_COD
            // 
            this.rdb_COD.AutoSize = true;
            this.rdb_COD.Location = new System.Drawing.Point(199, 261);
            this.rdb_COD.Name = "rdb_COD";
            this.rdb_COD.Size = new System.Drawing.Size(48, 17);
            this.rdb_COD.TabIndex = 12;
            this.rdb_COD.TabStop = true;
            this.rdb_COD.Text = "COD";
            this.rdb_COD.UseVisualStyleBackColor = true;
            this.rdb_COD.CheckedChanged += new System.EventHandler(this.rdn_COD_CheckedChanged);
            // 
            // rdb_NetBank
            // 
            this.rdb_NetBank.AutoSize = true;
            this.rdb_NetBank.Location = new System.Drawing.Point(290, 264);
            this.rdb_NetBank.Name = "rdb_NetBank";
            this.rdb_NetBank.Size = new System.Drawing.Size(70, 17);
            this.rdb_NetBank.TabIndex = 13;
            this.rdb_NetBank.TabStop = true;
            this.rdb_NetBank.Text = "Net Bank";
            this.rdb_NetBank.UseVisualStyleBackColor = true;
            // 
            // rdb_DebitCard
            // 
            this.rdb_DebitCard.AutoSize = true;
            this.rdb_DebitCard.Location = new System.Drawing.Point(417, 266);
            this.rdb_DebitCard.Name = "rdb_DebitCard";
            this.rdb_DebitCard.Size = new System.Drawing.Size(75, 17);
            this.rdb_DebitCard.TabIndex = 14;
            this.rdb_DebitCard.TabStop = true;
            this.rdb_DebitCard.Text = "Debit Card";
            this.rdb_DebitCard.UseVisualStyleBackColor = true;
            // 
            // btn_PlaceOrder
            // 
            this.btn_PlaceOrder.Location = new System.Drawing.Point(251, 324);
            this.btn_PlaceOrder.Name = "btn_PlaceOrder";
            this.btn_PlaceOrder.Size = new System.Drawing.Size(75, 23);
            this.btn_PlaceOrder.TabIndex = 15;
            this.btn_PlaceOrder.Text = "Place Order";
            this.btn_PlaceOrder.UseVisualStyleBackColor = true;
            this.btn_PlaceOrder.Click += new System.EventHandler(this.btn_PlaceOrder_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 389);
            this.Controls.Add(this.btn_PlaceOrder);
            this.Controls.Add(this.rdb_DebitCard);
            this.Controls.Add(this.rdb_NetBank);
            this.Controls.Add(this.rdb_COD);
            this.Controls.Add(this.ddl_cities);
            this.Controls.Add(this.ddl_quantities);
            this.Controls.Add(this.txt_ItemPrice);
            this.Controls.Add(this.txt_ItemName);
            this.Controls.Add(this.txt_CustomerName);
            this.Controls.Add(this.lbl_PaymentOption);
            this.Controls.Add(this.lbl_OrderCity);
            this.Controls.Add(this.lbl_ItemQty);
            this.Controls.Add(this.lbl_ItemPrice);
            this.Controls.Add(this.lbl_ItemName);
            this.Controls.Add(this.lbl_CustomerName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CustomerName;
        private System.Windows.Forms.Label lbl_ItemName;
        private System.Windows.Forms.Label lbl_ItemPrice;
        private System.Windows.Forms.Label lbl_ItemQty;
        private System.Windows.Forms.Label lbl_OrderCity;
        private System.Windows.Forms.Label lbl_PaymentOption;
        private System.Windows.Forms.TextBox txt_CustomerName;
        private System.Windows.Forms.TextBox txt_ItemName;
        private System.Windows.Forms.TextBox txt_ItemPrice;
        private System.Windows.Forms.ComboBox ddl_quantities;
        private System.Windows.Forms.ComboBox ddl_cities;
        private System.Windows.Forms.RadioButton rdb_COD;
        private System.Windows.Forms.RadioButton rdb_NetBank;
        private System.Windows.Forms.RadioButton rdb_DebitCard;
        private System.Windows.Forms.Button btn_PlaceOrder;
    }
}

