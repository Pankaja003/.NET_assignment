﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Sec_Application
{
    class Order
    {
        private int OrderId;
        private string CustomerName;
        private string ItemName;
        private int Price;
        private int qty;
        private string city;
        private string PaymentOption;
        private static int Count = 1000;
        public Order(string CustomerName,string ItemName,int Price,int qty,string city,string PaymentOption)
        {
            this.OrderId = ++Order.Count;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.Price = Price;
            this.qty = qty;
            this.city = city;
            this.PaymentOption = PaymentOption;
        } 
        public int POrderId
        {
            get
            {
                return this.OrderId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PItemName
        {
            get
            {
                return this.ItemName;
            }
        }
        public int PPrice
        {
            get
            {
                return this.Price;
            }
        }
        public int Pqty
        {
            get
            {
                return this.qty;
            }
        }
        public string Pcity
        {
            get
            {
                return this.city;
            }
        }
        public string PPaymentOption
        {
            get
            {
                return this.PaymentOption;
            }
        }
        public int getordervalue()
        {
            int amt = Price * qty;
            return amt;
        }
    }
}
