﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace win_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            if (txt_LoginId.Text == string.Empty)
            {
                lbl_loginid.Text = "Enter Login Id";
            }
            else if (txt_Password.Text == string.Empty)
            {
                lbl_Password.Text = "Enter your Password";
            }
            else
            {
                try
                {
                    int loginID = Convert.ToInt32(txt_LoginId.Text);
                    string password = txt_Password.Text;
                    MessageBox.Show("Four");
                    EmployeeDAL dal = new EmployeeDAL();
                    MessageBox.Show("Five");
                    bool status = dal.Login(loginID, password);
                    if (status == true)
                    {

                        Frm obj = new Frm();
                        obj.Show();
                    }
                    else
                    {
                        lbl_loginstatus.Text = "Invalid user Id or Password";
                    }
                }
                catch(System.Data.SqlClient.SqlException exp)
                {
                    MessageBox.Show("Data base Error ,contact admin");
                }

                catch (Exception exp)
                {
                    MessageBox.Show("six");
                    MessageBox.Show(exp.Message);
                }
            }
        }

    
       private void btn_NewUser_Click(object sender, EventArgs e)
    {
        Form_newUser obj = new Form_newUser();
        obj.Show();
    }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}