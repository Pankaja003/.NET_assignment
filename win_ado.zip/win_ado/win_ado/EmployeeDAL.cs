﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;//DLL ref
using System.Data;//ado.net
using System.Data.SqlClient;//ado.net




namespace win_ado
{
    class EmployeeDAL
    {
        SqlConnection con = new SqlConnection
(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int Addemployee(Employeemodel model)
        {
            try
            {
                SqlCommand com_addemployee = new SqlCommand("proc_addemployee", con);
                com_addemployee.CommandType = CommandType.StoredProcedure;
                com_addemployee.Parameters.AddWithValue("@name", model.Employeename);
                com_addemployee.Parameters.AddWithValue("@pwd", model.Employeepassword);
                com_addemployee.Parameters.AddWithValue("@city", model.Employeecity);
                com_addemployee.Parameters.AddWithValue("@salary", model.Employeesalary);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addemployee.Parameters.Add(para_return);
                con.Open();
                com_addemployee.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;

            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Login(int id, string password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);
                com_login.CommandType = CommandType.StoredProcedure;
                com_login.Parameters.AddWithValue("@id", id);
                com_login.Parameters.AddWithValue("@pwd", password);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(para_return);
                con.Open();
                System.Windows.Forms.MessageBox.Show("one");

                com_login.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("two");
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;

                }
                else
                {
                    return false;
                }
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("three");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


            }
        }

        public bool UpdateEmployee(int id, string city, int salary)
        {
            try
            {
                SqlCommand com_update_employee = new SqlCommand("proc_Updateemployee", con);
                com_update_employee.CommandType = CommandType.StoredProcedure;
                com_update_employee.Parameters.AddWithValue("@id", id);
                com_update_employee.Parameters.AddWithValue("@city", city);
                com_update_employee.Parameters.AddWithValue("@salary", salary);

                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_update_employee.Parameters.Add(para_return);
                con.Open();
                com_update_employee.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool DeleteEmployee(int id)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_deleteemployee", con);
                com_delete.CommandType = CommandType.StoredProcedure;
                com_delete.Parameters.AddWithValue("@id", id);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_delete.Parameters.Add(para_return);
                con.Open();
                com_delete.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        public Employeemodel Find(int id)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_findemployee", con);
                com_find.CommandType = CommandType.StoredProcedure;
                com_find.Parameters.AddWithValue("@id", id);
                con.Open();
                SqlDataReader dr = com_find.ExecuteReader();
                if (dr.Read())
                {
                    Employeemodel model = new Employeemodel();
                    model.Employeeid = dr.GetInt32(0);
                    model.Employeename = dr.GetString(1);
                    model.Employeepassword = dr.GetString(2);
                    model.Employeecity = dr.GetString(3);
                    model.Employeesalary = dr.GetInt32(4);
                    model.EmployeeDOJ = dr.GetDateTime(5);
                    con.Close();
                    return model;
                }
                con.Close();
                return null;

            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public List<Employeemodel> search(string key)
        {
            try
            {
                SqlCommand com_search = new SqlCommand("proc_searchemployee", con);
                com_search.CommandType = CommandType.StoredProcedure;
                com_search.Parameters.AddWithValue("@key", key);
                con.Open();
                SqlDataReader dr = com_search.ExecuteReader();
                List<Employeemodel> emplist = new List<Employeemodel>();
                while (dr.Read())
                {
                    Employeemodel model = new Employeemodel();
                    model.Employeeid = dr.GetInt32(0);
                    model.Employeename = dr.GetString(1);
                    model.Employeepassword = dr.GetString(2);
                    model.Employeecity = dr.GetString(3);
                    model.Employeesalary = dr.GetInt32(4);
                    model.EmployeeDOJ = dr.GetDateTime(5);
                    emplist.Add(model);
                }
                con.Close();
                return emplist;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }
    }
}
