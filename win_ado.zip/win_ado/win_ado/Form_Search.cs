﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ado
{
    public partial class Form_Search : Form
    {
        public Form_Search()
        {
            InitializeComponent();
        }

        private void btn_searchEmployee_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string key = txt_key.Text;
            List<Employeemodel> list = dal.search(key);
            dg_Employees.DataSource = list;
        }

        private void dg_Employees_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
