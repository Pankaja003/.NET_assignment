﻿namespace win_ado
{
    partial class Form_newUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Username = new System.Windows.Forms.Label();
            this.txt_username = new System.Windows.Forms.TextBox();
            this.lbl_City = new System.Windows.Forms.Label();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.lbl_salary = new System.Windows.Forms.Label();
            this.txt_Salary = new System.Windows.Forms.TextBox();
            this.btn_newuser = new System.Windows.Forms.Button();
            this.lbl_status = new System.Windows.Forms.Label();
            this.ddl_cities = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_Username
            // 
            this.lbl_Username.AutoSize = true;
            this.lbl_Username.Location = new System.Drawing.Point(75, 37);
            this.lbl_Username.Name = "lbl_Username";
            this.lbl_Username.Size = new System.Drawing.Size(55, 13);
            this.lbl_Username.TabIndex = 0;
            this.lbl_Username.Text = "Username";
            // 
            // txt_username
            // 
            this.txt_username.Location = new System.Drawing.Point(257, 37);
            this.txt_username.Name = "txt_username";
            this.txt_username.Size = new System.Drawing.Size(168, 20);
            this.txt_username.TabIndex = 1;
            // 
            // lbl_City
            // 
            this.lbl_City.AutoSize = true;
            this.lbl_City.Location = new System.Drawing.Point(75, 90);
            this.lbl_City.Name = "lbl_City";
            this.lbl_City.Size = new System.Drawing.Size(53, 13);
            this.lbl_City.TabIndex = 2;
            this.lbl_City.Text = "Password";
            // 
            // txt_Password
            // 
            this.txt_Password.Location = new System.Drawing.Point(257, 87);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(168, 20);
            this.txt_Password.TabIndex = 3;
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.Location = new System.Drawing.Point(77, 142);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(23, 13);
            this.lbl_Password.TabIndex = 4;
            this.lbl_Password.Text = "city";
            // 
            // lbl_salary
            // 
            this.lbl_salary.AutoSize = true;
            this.lbl_salary.Location = new System.Drawing.Point(77, 187);
            this.lbl_salary.Name = "lbl_salary";
            this.lbl_salary.Size = new System.Drawing.Size(36, 13);
            this.lbl_salary.TabIndex = 6;
            this.lbl_salary.Text = "Salary";
            // 
            // txt_Salary
            // 
            this.txt_Salary.Location = new System.Drawing.Point(257, 180);
            this.txt_Salary.Name = "txt_Salary";
            this.txt_Salary.Size = new System.Drawing.Size(168, 20);
            this.txt_Salary.TabIndex = 7;
            // 
            // btn_newuser
            // 
            this.btn_newuser.Location = new System.Drawing.Point(269, 248);
            this.btn_newuser.Name = "btn_newuser";
            this.btn_newuser.Size = new System.Drawing.Size(75, 23);
            this.btn_newuser.TabIndex = 8;
            this.btn_newuser.Text = "newuser";
            this.btn_newuser.UseVisualStyleBackColor = true;
            this.btn_newuser.Click += new System.EventHandler(this.btn_newuser_Click);
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lbl_status.Location = new System.Drawing.Point(75, 308);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(65, 13);
            this.lbl_status.TabIndex = 9;
            this.lbl_status.Text = "EmployeeId:";
            // 
            // ddl_cities
            // 
            this.ddl_cities.FormattingEnabled = true;
            this.ddl_cities.Location = new System.Drawing.Point(257, 142);
            this.ddl_cities.Name = "ddl_cities";
            this.ddl_cities.Size = new System.Drawing.Size(168, 21);
            this.ddl_cities.TabIndex = 11;
            // 
            // Form_newUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 382);
            this.Controls.Add(this.ddl_cities);
            this.Controls.Add(this.lbl_status);
            this.Controls.Add(this.btn_newuser);
            this.Controls.Add(this.txt_Salary);
            this.Controls.Add(this.lbl_salary);
            this.Controls.Add(this.lbl_Password);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.lbl_City);
            this.Controls.Add(this.txt_username);
            this.Controls.Add(this.lbl_Username);
            this.Name = "Form_newUser";
            this.Text = "Form_newUser";
            this.Load += new System.EventHandler(this.Form_newUser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Username;
        private System.Windows.Forms.TextBox txt_username;
        private System.Windows.Forms.Label lbl_City;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.Label lbl_salary;
        private System.Windows.Forms.TextBox txt_Salary;
        private System.Windows.Forms.Button btn_newuser;
        private System.Windows.Forms.Label lbl_status;
        private System.Windows.Forms.ComboBox ddl_cities;
    }
}