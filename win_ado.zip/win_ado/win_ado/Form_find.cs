﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ado
{
    public partial class Form_find : Form
    {
        public Form_find()
        {
            InitializeComponent();
        }

        private void Form_find_Load(object sender, EventArgs e)
        {
            ddl_Cities.Items.Add("Bgl");
            ddl_Cities.Items.Add("chenni");
            ddl_Cities.Items.Add("pune");
            ddl_Cities.Items.Add("mumbai");
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            if (txt_Eid.Text == string.Empty)
            {
                lbl_Employeestatus.Text = "enter the employee id";
            }
            else
            {
                int id = Convert.ToInt32(txt_Eid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                Employeemodel model = dal.Find(id);
                if(model!=null)
                {
                    txt_Name.Text = model.Employeename;
                    txt_Salary.Text = model.Employeesalary.ToString();
                    ddl_Cities.Text = model.Employeecity;
                    txt_EmployeeDoj.Text = model.EmployeeDOJ.ToString();


                }
                else
                {
                    lbl_Employeestatus.Text = "Employee not found";
                }
            }

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_Eid.Text);
            string city = ddl_Cities.Text;
            int salary = Convert.ToInt32(txt_Salary.Text);
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.UpdateEmployee(id, city, salary);
            if(status==true)
            {
                lbl_Employeestatus.Text = "Employee Updated";
            }
            else
            {
                lbl_Employeestatus.Text = "Not found";
            }

        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_Eid.Text);
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.DeleteEmployee(id);
            if(status==true)
            {
                lbl_Employeestatus.Text = "Deleted";
            }
            else
            {
                lbl_Employeestatus.Text = "Not Deleted";
            }
        }
    }
}
