﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace win_ado
{
    class Employeemodel
    {
        public int Employeeid
        {
            get;set;

        }
        public string Employeename { get; set; }
        public string Employeepassword { get; set; }
        public string Employeecity { get; set; }
        public int Employeesalary { get; set; }
        public DateTime EmployeeDOJ { get; set; }



    }
}
