﻿namespace win_ado
{
    partial class Form_Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Employeekey = new System.Windows.Forms.Label();
            this.txt_key = new System.Windows.Forms.TextBox();
            this.btn_searchEmployee = new System.Windows.Forms.Button();
            this.dg_Employees = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Employees)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Employeekey
            // 
            this.lbl_Employeekey.AutoSize = true;
            this.lbl_Employeekey.Location = new System.Drawing.Point(33, 41);
            this.lbl_Employeekey.Name = "lbl_Employeekey";
            this.lbl_Employeekey.Size = new System.Drawing.Size(76, 13);
            this.lbl_Employeekey.TabIndex = 0;
            this.lbl_Employeekey.Text = "Employee key:";
            // 
            // txt_key
            // 
            this.txt_key.Location = new System.Drawing.Point(146, 41);
            this.txt_key.Name = "txt_key";
            this.txt_key.Size = new System.Drawing.Size(100, 20);
            this.txt_key.TabIndex = 1;
            // 
            // btn_searchEmployee
            // 
            this.btn_searchEmployee.Location = new System.Drawing.Point(305, 37);
            this.btn_searchEmployee.Name = "btn_searchEmployee";
            this.btn_searchEmployee.Size = new System.Drawing.Size(75, 23);
            this.btn_searchEmployee.TabIndex = 2;
            this.btn_searchEmployee.Text = "search";
            this.btn_searchEmployee.UseVisualStyleBackColor = true;
            this.btn_searchEmployee.Click += new System.EventHandler(this.btn_searchEmployee_Click);
            // 
            // dg_Employees
            // 
            this.dg_Employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Employees.Location = new System.Drawing.Point(77, 94);
            this.dg_Employees.Name = "dg_Employees";
            this.dg_Employees.Size = new System.Drawing.Size(487, 155);
            this.dg_Employees.TabIndex = 3;
            this.dg_Employees.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_Employees_CellContentClick);
            // 
            // Form_Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 287);
            this.Controls.Add(this.dg_Employees);
            this.Controls.Add(this.btn_searchEmployee);
            this.Controls.Add(this.txt_key);
            this.Controls.Add(this.lbl_Employeekey);
            this.Name = "Form_Search";
            this.Text = "Form_Search";
            ((System.ComponentModel.ISupportInitialize)(this.dg_Employees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Employeekey;
        private System.Windows.Forms.TextBox txt_key;
        private System.Windows.Forms.Button btn_searchEmployee;
        private System.Windows.Forms.DataGridView dg_Employees;
    }
}