﻿namespace win_ado
{
    partial class Form_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Employeeid = new System.Windows.Forms.Label();
            this.txt_Eid = new System.Windows.Forms.TextBox();
            this.btn_Find = new System.Windows.Forms.Button();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_salary = new System.Windows.Forms.Label();
            this.txt_Name = new System.Windows.Forms.TextBox();
            this.txt_Salary = new System.Windows.Forms.TextBox();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.ddl_Cities = new System.Windows.Forms.ComboBox();
            this.lbl_Employeestatus = new System.Windows.Forms.Label();
            this.lbl_EmployeeDoJ = new System.Windows.Forms.Label();
            this.txt_EmployeeDoj = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_Employeeid
            // 
            this.lbl_Employeeid.AutoSize = true;
            this.lbl_Employeeid.Location = new System.Drawing.Point(76, 19);
            this.lbl_Employeeid.Name = "lbl_Employeeid";
            this.lbl_Employeeid.Size = new System.Drawing.Size(65, 13);
            this.lbl_Employeeid.TabIndex = 0;
            this.lbl_Employeeid.Text = "Employee Id";
            // 
            // txt_Eid
            // 
            this.txt_Eid.Location = new System.Drawing.Point(220, 16);
            this.txt_Eid.Name = "txt_Eid";
            this.txt_Eid.Size = new System.Drawing.Size(100, 20);
            this.txt_Eid.TabIndex = 1;
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(388, 19);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 23);
            this.btn_Find.TabIndex = 2;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Location = new System.Drawing.Point(79, 68);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(84, 13);
            this.lbl_Name.TabIndex = 3;
            this.lbl_Name.Text = "Employee Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 5;
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(79, 110);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(24, 13);
            this.lbl_city.TabIndex = 6;
            this.lbl_city.Text = "City";
            // 
            // lbl_salary
            // 
            this.lbl_salary.AutoSize = true;
            this.lbl_salary.Location = new System.Drawing.Point(79, 174);
            this.lbl_salary.Name = "lbl_salary";
            this.lbl_salary.Size = new System.Drawing.Size(36, 13);
            this.lbl_salary.TabIndex = 7;
            this.lbl_salary.Text = "Salary";
            // 
            // txt_Name
            // 
            this.txt_Name.Location = new System.Drawing.Point(220, 68);
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.Size = new System.Drawing.Size(100, 20);
            this.txt_Name.TabIndex = 8;
            // 
            // txt_Salary
            // 
            this.txt_Salary.Location = new System.Drawing.Point(221, 174);
            this.txt_Salary.Name = "txt_Salary";
            this.txt_Salary.Size = new System.Drawing.Size(100, 20);
            this.txt_Salary.TabIndex = 10;
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(79, 218);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(75, 23);
            this.btn_Update.TabIndex = 11;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(245, 227);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 23);
            this.btn_Delete.TabIndex = 12;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // ddl_Cities
            // 
            this.ddl_Cities.FormattingEnabled = true;
            this.ddl_Cities.Location = new System.Drawing.Point(200, 110);
            this.ddl_Cities.Name = "ddl_Cities";
            this.ddl_Cities.Size = new System.Drawing.Size(121, 21);
            this.ddl_Cities.TabIndex = 13;
            // 
            // lbl_Employeestatus
            // 
            this.lbl_Employeestatus.AutoSize = true;
            this.lbl_Employeestatus.Location = new System.Drawing.Point(67, 258);
            this.lbl_Employeestatus.Name = "lbl_Employeestatus";
            this.lbl_Employeestatus.Size = new System.Drawing.Size(86, 13);
            this.lbl_Employeestatus.TabIndex = 14;
            this.lbl_Employeestatus.Text = "Employee Status";
            // 
            // lbl_EmployeeDoJ
            // 
            this.lbl_EmployeeDoJ.AutoSize = true;
            this.lbl_EmployeeDoJ.Location = new System.Drawing.Point(79, 142);
            this.lbl_EmployeeDoJ.Name = "lbl_EmployeeDoJ";
            this.lbl_EmployeeDoJ.Size = new System.Drawing.Size(72, 13);
            this.lbl_EmployeeDoJ.TabIndex = 15;
            this.lbl_EmployeeDoJ.Text = "Employee Doj";
            // 
            // txt_EmployeeDoj
            // 
            this.txt_EmployeeDoj.Location = new System.Drawing.Point(220, 139);
            this.txt_EmployeeDoj.Name = "txt_EmployeeDoj";
            this.txt_EmployeeDoj.Size = new System.Drawing.Size(100, 20);
            this.txt_EmployeeDoj.TabIndex = 16;
            // 
            // Form_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 327);
            this.Controls.Add(this.txt_EmployeeDoj);
            this.Controls.Add(this.lbl_EmployeeDoJ);
            this.Controls.Add(this.lbl_Employeestatus);
            this.Controls.Add(this.ddl_Cities);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.txt_Salary);
            this.Controls.Add(this.txt_Name);
            this.Controls.Add(this.lbl_salary);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_Name);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.txt_Eid);
            this.Controls.Add(this.lbl_Employeeid);
            this.Name = "Form_find";
            this.Text = "Form_find";
            this.Load += new System.EventHandler(this.Form_find_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Employeeid;
        private System.Windows.Forms.TextBox txt_Eid;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_salary;
        private System.Windows.Forms.TextBox txt_Name;
        private System.Windows.Forms.TextBox txt_Salary;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.ComboBox ddl_Cities;
        private System.Windows.Forms.Label lbl_Employeestatus;
        private System.Windows.Forms.Label lbl_EmployeeDoJ;
        private System.Windows.Forms.TextBox txt_EmployeeDoj;
    }
}