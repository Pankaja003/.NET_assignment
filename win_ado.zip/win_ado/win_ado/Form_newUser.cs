﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ado
{
    public partial class Form_newUser : Form
    {
        public Form_newUser()
        {
            InitializeComponent();
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            if(txt_username.Text==string.Empty)
            {
                lbl_status.Text = "Enter Employee name";

            }
            else if(txt_Password.Text==string.Empty)
            {
                lbl_status.Text = "Enter Employee password";
            }
            else if(ddl_cities.Text==string.Empty)
            {
                lbl_status.Text = "Select city";
            }
            else if(txt_Salary.Text==string.Empty)
            {
                lbl_status.Text = "Enter Salary";
            }
            else
            {
                Employeemodel model = new Employeemodel();
                model.Employeename = txt_username.Text;
                model.Employeepassword = txt_Password.Text;
                model.Employeecity = ddl_cities.Text;
                model.Employeesalary = Convert.ToInt32(txt_Salary.Text);
                EmployeeDAL dal = new EmployeeDAL();
                int id = dal.Addemployee(model);
                lbl_status.Text = "Employee Added, Id:" + id;
            }

        }

        private void Form_newUser_Load(object sender, EventArgs e)
        {
            ddl_cities.Items.Add("BGL");
            ddl_cities.Items.Add("chenni");
            ddl_cities.Items.Add("mumbai");
            ddl_cities.Items.Add("pune");
            ddl_cities.Items.Add("up");

        }
    }
}
