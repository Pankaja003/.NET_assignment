create database db_customer_ado

create table tbl_customers
(
CustomerId int identity(1001,1) primary key,
CustomerName varchar(100) not null,
Customerpassword varchar(100) not null,
Customercity varchar(100) not null,
CustomerAdd varchar(100) not null,
CustomerMobileno varchar(100) not null,
CustomerEmailID varchar(100) not null
)

create proc proc_addcustomer(@name varchar(100),@pwd varchar(100),@city varchar(100),@addr varchar(100),@mobileno varchar(100),@email varchar(100))
as
begin
insert tbl_customers values(@name,@pwd,@city ,@addr,@mobileno,@email )
return @@identity
end

create proc proc_updatecustomer(@id int,@city varchar(100),@addr varchar(100),@mobileno varchar(100))
as
begin
update tbl_Customers set Customercity=@city,CustomerAdd=@addr,CustomerMobileno=@mobileno
where customerid=@id
return @@rowcount
end


create proc proc_deletecustomer(@id int)
as
begin
delete tbl_Customers where Customerid=@id
return @@rowcount
end

create proc proc_findcustomer(@id int)
as
begin
select * from tbl_customers where customerid=@id
end

create proc proc_searchcustomer(@key varchar(100))
as
begin
select * from tbl_customers where CustomerId like '%'+@key+'%'
                                      or Customername like '%'+@key+'%'

end

create proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int=0
select @count=count(*) from tbl_customers
where customerid=@id and Customerpassword=@pwd
return @count
end

select * from tbl_customers



