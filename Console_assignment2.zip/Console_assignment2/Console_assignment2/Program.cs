﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter AccountID:");
            int acc_Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter customer address:");
            string address = Console.ReadLine();
            int bal =1000;
            bool flag = true;
           
            while(flag)
            {
                Console.WriteLine("1-deposite,2-withdraw,3-balance,4-exit");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch(opt)
                {
                    case 1:
                        {
                            
                            Console.WriteLine("Enter amount to deposite:");
                            int amount = Convert.ToInt32(Console.ReadLine());
                            bal = bal + amount;
                            Console.WriteLine("Balance Deposited");
                          
                            break;
                         }
                    case 2:
                        {
                            Console.WriteLine("Enter amount to withdraw:");
                            int amount = Convert.ToInt32(Console.ReadLine());
                            if(bal>500)
                            {
                                bal = bal - amount;
                                Console.WriteLine("Amount is Withdrawed");

                            }
                            else
                            {
                                Console.WriteLine("Dont have suffcient balance");
                            }
                            break;
                        }

                    case 3:
                        {
                            Console.WriteLine("Balance is:" + bal);
                            break;
                        }
                    case 4:
                        {
                            flag = false;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid option");
                            break;
                        }

                }
        
            }
                
        }
    }
}
