﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_string
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Helzy";
            // string s = str.Substring(1,2);
            //Console.WriteLine(s);
            char[] ch = str.ToCharArray();
            for(int i=0;i<ch.Length;i++)
            {
                // Console.WriteLine(ch[i]);
                int no = Convert.ToInt32(ch[i]);//convert char to ascci no
                int max = Convert.ToChar('z');
                int max1 = Convert.ToChar('y');
                if (no == max)
                {
                   //no = Convert.ToChar('a');
                    no = Convert.ToChar('b');

                }
                if(no==max1)
                    {
                    no = Convert.ToChar('a');
                }
                else
                {
                   // no++;//increment ascci no
                   no = no + 2; //for 2 increment
                }
                ch[i] = Convert.ToChar(no);//convert no to char
            }
            string newstr = new string(ch);
            Console.WriteLine(newstr);


            /*string str = "abc";
            char[] ch = { 'a', 'b', 'c' };

            object obj = new string (ch);
            if(str==obj)
            {
                Console.WriteLine("true");
            }
            else
            {
                Console.WriteLine("false");
            }
            if(str.Equals(obj))
            {
                Console.WriteLine("Content is same");
            }
            else
            {
                Console.WriteLine("content are not same");
            }*/
            Console.ReadLine();

        }
    }
}
