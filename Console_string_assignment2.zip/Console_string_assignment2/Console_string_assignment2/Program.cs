﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_string_assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Megha";
            char[] c = str.ToArray();
            bool flag = true;
            for(int i=0;i<c.Length;i++)
            {
                for(int j=i+1;j<c.Length;j++)
                {
                    if(c[i]==c[j])
                    {
                        flag = false;
                        break;
                    }
                }
            }
            if(flag==true)
            {
                Console.WriteLine("unique");
            }
            else
            {
                Console.WriteLine("not unique");
            }
            Console.ReadLine();
        }
    }
}
