﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_practice1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* string name = "abcd";
             String add = "xtz";
             int salary = 3000;
             Console.WriteLine("NAME is :" + name);
             Console.WriteLine("ADDRESS is :" + add);
             Console.WriteLine("SALARY is:" + salary);*/
            /*Console.WriteLine("Enter name:");
             string name = Console.ReadLine();
             Console.WriteLine("Enter address:");
             string add = Console.ReadLine();
             Console.WriteLine("Enter salary:");
             int salary = Convert.ToInt32(Console.ReadLine());
             Console.WriteLine("NAME is :" + name);
             Console.WriteLine("ADDRESS is :" + add);
             Console.WriteLine("SALARY is:" + salary);*/
            bool flag = true;
            int count = 0;
            while (flag)
            {
                Console.WriteLine("Enter userId:");
                String userId = Console.ReadLine();
                Console.WriteLine("Enter password:");
                string Password = Console.ReadLine();
                if (userId=="abcd" && Password=="Pass@123")
                {
                    Console.WriteLine("Valid user");
                    flag = false;
                }
                else
                {
                    Console.WriteLine("Invalid user");
                }
                count++;
                if(count==3)
                {
                    flag = false;
                    Console.WriteLine("Limit is Over");
                }
                
            }


            Console.ReadLine();
        }
    }
}
