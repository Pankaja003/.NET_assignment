﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Console_Collection_Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> names = new Dictionary<int, string>();
            names.Add(1, "Jhon");
            names.Add(2, "peter");
            names.Add(33, "David");
            names.Add(100, "Rosy");

            foreach(KeyValuePair<int,string> kv in names)
            {
                Console.WriteLine(kv.Key + " " + kv.Value);
            }
            foreach(string v in names.Values)
            {
                Console.WriteLine(v);
            }
            foreach(int k in names.Keys)
            {
                Console.WriteLine(k);
            }
            string s1 = names[100];
            Console.WriteLine(s1);
            names.Remove(33);
             if(names.ContainsKey(77))
            {
                string s = names[77];
                Console.WriteLine(s);
            }




            /*List<int> marks = new List<int>();
            marks.Add(88);
            marks.Add(77);
            marks.Add(90);
            marks.Add(66);
            marks.Add(55);
            for(int c=0;c<marks.Count;c++)
            {
                int i = marks[c];
                Console.WriteLine(i);
            }
            marks.Remove(77);
            marks[1] = 99;
            marks.Sort();
            marks.Reverse();
            Console.WriteLine("*********");
            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }*/



            /*Test obj = new Test();
            int x = obj.Call<int>(100);
            Console.WriteLine(x);
            string str = obj.Call<string>("Hello");
            Console.WriteLine(str);*/




            /*ArrayList names = new ArrayList();
            Console.WriteLine(names.Count);
            names.Add("Jhon");//0 object o="jhon"
            names.Add("David");//1
            int i = 1000;
            names.Add(i);//object o=i;
            names[0] = "Pooja";
            string s = names[0].ToString();
            for(int c=0;c<names.Count;c++)
            {
                string str = names[c].ToString();
                Console.WriteLine(str);
            }
            foreach(string sk in names)
            {
                Console.WriteLine(sk);
            }
            Console.WriteLine(names.Count);
            names.Remove("Jhon");
            names.RemoveAt(0);
            Console.WriteLine(names.Count);*/
            Console.ReadLine();

            

        }
    }
}
