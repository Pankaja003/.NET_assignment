﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_lambda
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Employee> emplist = new List<Employee>();

            Employee e1 = new Employee();
            e1.EmployeeID = 1;
            e1.EmployeeName = "jhon";
            e1.EmployeeCity = "a";
            e1.EmployeeSalary = 40000;




            Employee e2 = new Employee();
            e2.EmployeeID = 2;
            e2.EmployeeName = "kkjhjh";
            e2.EmployeeCity = "b";
            e2.EmployeeSalary = 50000;

            Employee e3 = new Employee();
            e3.EmployeeID = 3;
            e3.EmployeeName = "xccv";
            e3.EmployeeCity = "c";
            e3.EmployeeSalary = 60000;

            emplist.Add(e1);
            emplist.Add(e2);
            emplist.Add(e3);


            var q = from e in emplist
                    where e.EmployeeSalary > 20000
                    select e;
            var l = emplist.Where(e => e.EmployeeSalary > 20000);
            foreach (var ee in q)
            {
                Console.WriteLine(ee.EmployeeID + " " + ee.EmployeeName);
            }
            Console.ReadLine();
        }
    }
    }

