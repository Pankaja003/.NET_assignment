﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_assignmentp
{
    class Account
    {
        private int AccountId;
        private string CustomerName;
        private int AccountBal;
        public Account(int AccountId,string CustomerName,int AccountBal)
        {
            this.AccountId = AccountId;
            this.CustomerName = CustomerName;
            this.AccountBal = AccountBal;
            Console.WriteLine("Object Is Constructed");

        }
        public int GetAccountId()
        {
            return this.AccountId;
        }
        public string GetCusomerName()
        {
            return this.CustomerName;
        }
        public void Deposite(int amt)
        {
            this.AccountBal = this.AccountBal + amt;

        }
        public void Withdraw(int amt)
        {
            this.AccountBal = this.AccountBal - amt;

        }
        public int GetAccountBal()
        {
            return this.AccountBal;
        }

    }
}
