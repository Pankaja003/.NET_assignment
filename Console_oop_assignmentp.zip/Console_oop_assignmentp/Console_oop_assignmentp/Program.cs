﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_assignmentp
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Account obj = new Account(1, "xyz", 4000);
             int Id = obj.GetAccountId();
             string name = obj.GetCusomerName();
             int bal = obj.GetAccountBal();
             Console.WriteLine("Id is:" + Id.ToString());
             Console.WriteLine("Name is:" + name);
             Console.WriteLine("Balance is:" + bal.ToString());
             obj.Deposite(4000);
              bal = obj.GetAccountBal();
             Console.WriteLine("Deposited:" + bal);
             obj.Withdraw(500);
             bal = obj.GetAccountBal();
             Console.WriteLine("Withdrawed:" + bal);*/
            /*  Employee obj = new Employee(1, "abs", 24, 30000);
              int Id = obj.GetEmployeeID();
              string name = obj.GetEmployeeName();
              int age = obj.GetEmployeeAge();
              int salary = obj.GetEmployeeSalary();
              Console.WriteLine("Id is:" + Id.ToString());
              Console.WriteLine("Name is:" + name);
              Console.WriteLine("Age is:" + age.ToString());
              Console.WriteLine("Salary is:" + salary.ToString());
              obj.HappyBirthday();
              age = obj.GetEmployeeAge();
              Console.WriteLine("Age is:" + age);
              obj.GetSalaryIncrement(6000);
              salary = obj.GetEmployeeSalary();
              Console.WriteLine("Salary is:" + salary);*/
            Order obj = new Order(1, "abc", "xyz", 4, 500);
            int Id = obj.GetOrderId();
            string name = obj.GetCustomerName();
            string itemname = obj.GetItemName();
            int quantity = obj.GetItemQuantity();
            int price = obj.GetItemPrire();
            Console.WriteLine("Id is:" + Id.ToString());
            Console.WriteLine("Name is:" + name);
            Console.WriteLine("ItemName is:" + itemname);
            Console.WriteLine("Quantity is:" + quantity);
            Console.WriteLine("Price is:" + price);
            obj.GetOrderAmount();
             int amt = obj.GetOrderAmount();
            Console.WriteLine("Order amount is:" + amt );
            obj.UpdateItemQuantity(5);
            quantity= obj.GetItemQuantity();
            Console.WriteLine("Quantity is :" +quantity );
            obj.GetOrderAmount();
             amt= obj.GetOrderAmount();
            Console.WriteLine("Order amount is:" + amt);
            Console.ReadLine();
        }
    }
}
