﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_assignmentp
{
    class Order
    {
        private int OrderId;
        private string CustomerName;
        private string ItemName;
        private int ItemQuantity;
        private int ItemPrice;
        public Order(int OrderId,string CustomerName,string ItemName,int ItemQuantity,int ItemPrice)
        {
            this.OrderId = OrderId;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
            Console.WriteLine("Object is Constructed");
        }
        public int GetOrderId()
        {
            return this.OrderId;
        }
        public string GetCustomerName()
        {
            return this.CustomerName;
        }
        public String GetItemName()
        {
            return this.ItemName;

        }
        public int GetItemQuantity()
        {
            return this.ItemQuantity;
        }
        public int GetItemPrire()
        {
            return this.ItemPrice;
        }
      public int GetOrderAmount()
        {
             int amt = ItemQuantity * ItemPrice;
            return amt;
        }
        public void UpdateItemQuantity(int num)
        {
            this.ItemQuantity = num;
        }
    }
}
