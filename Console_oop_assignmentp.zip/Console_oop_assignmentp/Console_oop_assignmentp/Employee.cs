﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_assignmentp
{
    class Employee
    {
        private int EmployeeID;
        private string EmployeeName;
        private int EmployeeAge;
        private int EmployeeSalary;
        public Employee(int EmployeeID,string EmployeeName,int EmployeeAge,int EmployeeSalary)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeAge = EmployeeAge;
            this.EmployeeSalary = EmployeeSalary;
            Console.WriteLine("Object Is Constructed");

        }
        public int GetEmployeeID()
        {
            return this.EmployeeID;

        }
        public string GetEmployeeName()
        {
            return this.EmployeeName;
        }
        public int GetEmployeeAge()
        {
            return this.EmployeeAge;
        }
        public void HappyBirthday()
        {
            this.EmployeeAge = this.EmployeeAge + 1;

        }
        public void GetSalaryIncrement(int amt)
        {
            this.EmployeeSalary = this.EmployeeSalary + amt;

        }
        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }


    }
}
