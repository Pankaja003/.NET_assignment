﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Console_Threads
{
    class Program
    {
        static void Main(string[] args)
        {
           /* int c, c2;
            ThreadPool.GetMaxThreads(out c, out c2);
            Console.WriteLine(c);*/

            Task t = Task.Run(() =>
            {
                Console.WriteLine("Task 1 Started...");
                Thread.Sleep(5000);
                Console.WriteLine("Task 1 Completed......");
            });
                


           /* ThreadPool.SetMaxThreads(10, 1000);
            ThreadPool.SetMinThreads(5, 1000);
            int count = 0;
            Test obj = new Test();
            while(count<20)
            {
                ThreadPool.QueueUserWorkItem(obj.MyTask, count);
                count++;
            }
            Console.WriteLine("Main Thread is Free Now");
            */

  /*
            Test obj = new Test();
            Thread th1 = new Thread(obj.GetSum);
            th1.Start();
            Thread th2 = new Thread(obj.GetSum);
            th2.Start();*/


           /* Test obj = new Test();
            Thread th1 = new Thread(obj.Call1);
            th1.Start();//new thread
            Thread th2 = new Thread(obj.Call2);
            th2.Start();//new thread

            //obj.Call1();
            //obj.Call2();
            th1.Join();//Main Thread
            Console.WriteLine("Main Method Code");*/
            Console.ReadLine();
        }
    }
}
