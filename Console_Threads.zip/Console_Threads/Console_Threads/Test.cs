﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Console_Threads
{
    class Test
    {
        public void Call1()
        {
            Console.WriteLine("Call1 is Started");
            Thread.Sleep(10000);
            Console.WriteLine("Call1 is Ended");
        }

        public void Call2()
        {
            Console.WriteLine("Call2 is Started");
            Thread.Sleep(10000);
            Console.WriteLine("Call2 is Ended");
        }

        int total = 0;
        public void GetSum()
        {
            /*
            lock (this)
            {
              total = total + 100;

                Thread.Sleep(5000);
                Console.WriteLine("Total:" + total);
            }*/

            if (Monitor.TryEnter(this,100))
            {
                Console.WriteLine("Thread Started");
                total = total + 100;
                Thread.Sleep(10);
                Console.WriteLine("Total:" + total);
                Monitor.Exit(this);
            }
            else
            {
                Console.WriteLine("Try after sometime");
            }
        }

        public void MyTask(object obj)
        {
            Console.WriteLine("My Task:" + obj + 
                ",Thread ID:" + Thread.CurrentThread.ManagedThreadId);
            Thread.Sleep(10000);
            Console.WriteLine("Task is Over"+obj);
            
        }

    }
}
