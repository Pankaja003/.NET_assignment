﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Account Balance:");
            int bal = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Account Type:");
            string type = Console.ReadLine();
            Account obj = null;
            if(type=="Savings")
            {
                obj = new Saving(name, bal);

            }
            else if(type=="Current")
                  {
                obj = new Current(name, bal);
            }
            if(obj!=null)
            {
                Console.WriteLine(obj.PAccountId);
                Console.WriteLine(obj.PCustomerName);
               int accbalance= obj.GetBalance() ;
                Console.WriteLine(" Balance is:" + accbalance);
                Console.WriteLine("Enter an Amount to Deposite:");
                int amt = Convert.ToInt32(Console.ReadLine());
                obj.Deposite(amt);
                accbalance = obj.GetBalance();
                Console.WriteLine("New Balance is:" + accbalance);
                Console.WriteLine("Enter the Amount to Withdraw:");
                amt = Convert.ToInt32(Console.ReadLine());
                obj.Withdraw(amt);
                accbalance = obj.GetBalance();
                Console.WriteLine("New Balance is:" + accbalance);
                obj.StopPayment(1001);


            }

            Console.ReadLine();
        }
    }
}
