﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Current:Account
    {
        public Current(string CustomerName,int AccountBal)
              :base(CustomerName,AccountBal)
        {
            Console.WriteLine("Current Object is Constructed");
        }

        public override void Deposite(int amt)
        {
            this.AccountBal = this.AccountBal + amt;
        }

        public override void Withdraw(int amt)
        {
            this.AccountBal = this.AccountBal - amt;

        }
    }
}
