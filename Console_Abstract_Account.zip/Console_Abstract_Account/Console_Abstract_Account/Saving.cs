﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Saving :Account
    {
        public Saving(string CustomerName,int AccountBal)
              :base(CustomerName,AccountBal)
        {
            Console.WriteLine("Saving Object Constructor");
        }

        public override void Deposite(int amt)
        {
            this.AccountBal = this.AccountBal + amt + 100;
        }

        public override void Withdraw(int amt)
        {
            this.AccountBal = this.AccountBal - amt - 100;
        }
    }
}
