﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
     abstract class Account
    {
        private int AccountId;
        private string CustomerName;
        protected int AccountBal;
        private static int count;
        public Account(string CustomerName,int AccountBal)
        {
            this.AccountId = ++Account.count;
            this.CustomerName = CustomerName;
            this.AccountBal = AccountBal;
            Console.WriteLine("Account Class Object Constructed");

        }
        public int PAccountId
        {
            get
            {
                return this.AccountId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }

        }
        public int GetBalance()
        {
            return this.AccountBal;
        }
        public void StopPayment(int ChequeNo)
        {
            Console.WriteLine("Payment is Stoped,ref cheque no:" + ChequeNo);

        }
        public abstract void Deposite(int amt);
        public abstract void Withdraw(int amt);
    }
}
