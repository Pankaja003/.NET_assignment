﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Delegates
{
    class Program
    {
        public static void getinfo(string s)
        {
            Console.WriteLine("Static function:" +s);
        }
        static void Main(string[] args)
        {
            Test obj = new Test();
            Test.del d = new Test.del(obj.call);//d is holding addresss of obj.call
            d += obj.getdata;//multicast delegate
            d -= obj.getdata;
            d += Program.getinfo;
            d += delegate (string s)//call at run time
              {
                  Console.WriteLine("Anonymous Function:" + s);
              };
            d += (s) => Console.WriteLine("Lambda Expression:" + s);

            d("Hello");//this hello is copied to call
            Console.ReadLine(); 
        }
    }
}
