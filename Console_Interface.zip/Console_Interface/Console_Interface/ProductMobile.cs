﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class ProductMobile:IProduct,IProductTesting
    {
        private int MobileId;
        private string MobileNO;
        private int MobilePrice;
        private string MobileName;
        public  ProductMobile(int MobileId, string MobileNo, int MobilePrice, string MobileName)
        {
            this.MobileId = MobileId;
            this.MobileNO = MobileNo;
            this.MobilePrice = MobilePrice;
            this.MobileName = MobileName;
        }

        public int GetProductPrice()
        {
            return this.MobilePrice;
        }

        public string GetProductName()
        {
            return this.MobileName;
        }

        public int GetProductId()
        {
            return this.MobileId;

        }
       public void start()

        {
            Console.Write("Start");

        }
        public void stop()
        {
            Console.WriteLine("stop");
        }

    }
}
