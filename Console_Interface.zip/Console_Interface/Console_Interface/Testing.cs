﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Testing
    {
        public void AddProduct(IProductTesting P)
        {
            int id = P.GetProductId();
            Console.WriteLine("testing Dept,Product ID:" + id);
               
            P.start();
            P.stop();
        }
    }
}
