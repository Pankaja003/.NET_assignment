﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class ProductBook :IProduct
    {
        private int BookId;
        private string BookName;
        private string AuthorName;
        private int BookPrice;
        private int NoOfPages;
        public ProductBook(int BookId,string BookName,string AuthorName,int BookPrice,int NoOfPages)
        {
            this.BookId = BookId;
            this.BookName = BookName;
            this.AuthorName = AuthorName;
            this.BookPrice = BookPrice;
            this.NoOfPages = NoOfPages;
        }

        public int GetProductPrice()
        {
            return this.BookPrice;
        }

        public string GetProductName()
        {
            return this.BookName;
        }

        public int GetProductId()
        {
            return this.BookId;
        }
    }
}
