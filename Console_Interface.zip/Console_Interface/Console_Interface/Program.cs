﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductBook objb = new ProductBook(1, "C#", "Ms", 2000, 1000);
            ProductMobile objm = new ProductMobile(1001, "Oneplus", 35000, "Oneplus");
            Testing t = new Testing();
            t.AddProduct(objm);
            Order o1 = new Order();
            o1.AddProduct(objb);
            Order o2 = new Order();
            o2.AddProduct(objm);
            Console.ReadLine();

        }
    }
}
