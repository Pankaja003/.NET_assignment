﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Order
    {

        public void AddProduct(IProduct p)
        {
            int price = p.GetProductPrice();
            string name = p.GetProductName();
            int id = p.GetProductId();
            Console.WriteLine("Product ID is:" + id);
            Console.WriteLine("Product Name is:" + name);
            Console.WriteLine("Product price is:" + price);
        }
    }
}
