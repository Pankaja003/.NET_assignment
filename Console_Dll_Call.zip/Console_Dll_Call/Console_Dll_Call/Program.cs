﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Dll_Call
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the no of days:");
            int noofdays = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the per day salary:");
            int perdaysalary = Convert.ToInt32(Console.ReadLine());
            TeatLibraray.Test dll = new TeatLibraray.Test();
            int salary = dll.GetSalary(perdaysalary, noofdays);
            Console.WriteLine("salary:" + salary);
            Console.ReadLine();

        }
    }
}
