﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment__Abstract
{
    abstract class Loan
    {
        protected int LoanId;
        protected string CustomerName;
        protected string CustomerEmailId;
        protected string CustomerMobileNo;
        protected int LoanAmount;
        protected int Duration;
        protected int Rate;
        protected int a;
        private static int count;
        public Loan(string CustomerName, string CustomerEmailId, string CustomerMobileNo, int LoanAmount, int Duration, int Rate)
        {
            this.LoanId = ++Loan.count;
            this.CustomerName = CustomerName;
            this.CustomerEmailId = CustomerEmailId;
            this.CustomerMobileNo = CustomerMobileNo;
            this.LoanAmount = LoanAmount;
            this.Duration = Duration;
            this.Rate = Rate;
            Console.WriteLine("Loan Class Object Constructed");

        }
        public int PLoanId
        {
            get
            {
                return this.LoanId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;

            }
        }
        public string PCustomerEmailId
        {
            get
            {
                return this.CustomerEmailId;
            }
        }
        public string PCustomerMobileNo
        {
            get
            {
                return this.CustomerMobileNo;
            }
        }
        public int PLoanAmount
        {
            get
            {
                return this.LoanAmount;
            }
        }
        public int PDuration
        {
            get
            {
                return this.Duration;
            }
        }
        public int PRate
        {
            get
            {
                return this.Rate;
            }
        }

        public abstract int GetPendingLoan();
        
           
        
        public abstract int PayEMI(int amount);

    }
    
}
