﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment__Abstract
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the EmailId:");
            string email = Console.ReadLine();
            Console.WriteLine("Enter the Customer no:");
            string num = Console.ReadLine();
            Console.WriteLine("Enter Loan Amount:");
            int loan = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter  Duration:");
            int dur = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Rate:");
            int rate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the type:");
                string type = Console.ReadLine();
            Loan obj = null;
            if(type=="Home_Loan")
            {
                obj = new Home_Loan(name, email, num, loan, dur, rate);
            }
            else if(type=="Vehicle_Loan")
            {
                obj = new Vehicle_Loan(name, email, num, loan, dur, rate);
            }
            if(obj!=null)
            {
                Console.WriteLine(obj.PLoanId);
                Console.WriteLine(obj.PCustomerName);
                Console.WriteLine(obj.PCustomerEmailId);
                Console.WriteLine(obj.PCustomerMobileNo);
                Console.WriteLine(obj.PLoanAmount);
                Console.WriteLine(obj.PDuration);
                Console.WriteLine(obj.PRate);
                Console.WriteLine("Enter the amount to be paid:");
                int amount = Convert.ToInt32(Console.ReadLine());
               int a=obj.PayEMI(amount);
                Console.WriteLine("Monthly EMI is :" + a);
               
       
                int pend = obj.GetPendingLoan();

            
                Console.WriteLine("The pending Loan Amount is :" + pend);


            }
            Console.ReadLine();
        }
    }
}
