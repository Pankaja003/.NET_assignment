﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment__Abstract
{
    class Home_Loan:Loan
    {
        public Home_Loan(string CustomerName, string CustomerEmailId, string CustomerMobileNo, int LoanAmount, int Duration, int Rate)
            :base (CustomerName, CustomerEmailId, CustomerMobileNo, LoanAmount, Duration, Rate)
        {
            Console.WriteLine("Home_Loan Object Constructed");
        }

        public override int  PayEMI(int amount)
        {
            a = LoanAmount / Duration + amount;
            return a;
        }
        public override int GetPendingLoan()
        {
            int rem = LoanAmount - a;
            return rem;
        }
    }
}
