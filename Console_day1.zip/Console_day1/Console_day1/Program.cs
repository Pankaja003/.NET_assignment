﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            string name="pathfront";

            string city="BGL";
            int salary=30000;
            Console.WriteLine("Employee Name:" + name);
            Console.WriteLine("Employee City:" + city);
            Console.WriteLine("Employee Salary:" + salary);
            */
            /*
            Console.WriteLine("Enter Your Name:");
            string name = Console.ReadLine();//it return string
            Console.WriteLine("Enter Your city:");
            String city = Console.ReadLine();
            Console.WriteLine("Enter Your Age:");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Your Name:" + name);
            Console.WriteLine("Your city:" + city);
            Console.WriteLine("Your age:" + age.ToString());
            */
            bool flag = true;
            int count = 0;
            while(flag)
            {
                
                Console.WriteLine("Enter Your User ID:");
            string userid = Console.ReadLine();
            Console.WriteLine("Enter Your Password:");
            string password = Console.ReadLine();
            if(userid=="user1" && password=="pass@123")
            {
                Console.WriteLine("Valid User");
                    flag = false;

            }
            else
            {
                Console.WriteLine("Invalid User");
            }
                count++;
                if (count == 3)
                {
                    flag = false;
                    Console.WriteLine("Limit is over");
                }
            }

            
            Console.ReadLine();

                
              
         
        }
  }
}
