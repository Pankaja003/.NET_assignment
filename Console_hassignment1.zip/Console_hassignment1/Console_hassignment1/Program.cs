﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_hassignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number 1:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number 2:");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Before swapping:");
            Console.WriteLine("NUM 1 is:" + num1);
            Console.WriteLine("NUM 2 is:" + num2);

            num1 = num1 + num2;
            num2 = num1 - num2;
            num1 = num1 - num2;
            Console.WriteLine("After swapping:");
            Console.WriteLine("NUM 1 is :" + num1);
            Console.WriteLine("NUM 2 is :" + num2);


            Console.ReadLine();
        }
    }
}
